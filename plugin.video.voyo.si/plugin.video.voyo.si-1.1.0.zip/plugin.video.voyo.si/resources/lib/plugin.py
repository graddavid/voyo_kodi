# -*- coding: utf-8 -*-
"""Directory listings, playback and routing."""

import json

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import account
from resources.lib import kodiutils as ku
from resources.lib.voyo_api import (
    GROUP_CONTINUE, GROUP_MY_VOYO, LIVE_CHANNELS, TooManyDevicesError, VoyoError, resize_image,
)

SEARCH_HISTORY_FILE = "search_history.json"
SEARCH_HISTORY_SIZE = 15

MOVIE_GENRES = [
    ("Vsi filmi", "/filmi/vsi-filmi"),
    ("Slovenski", "/filmi/slovenski"),
    ("Kratki filmi", "/filmi/kratki-filmi"),
    ("Akcija", "/filmi/akcija"),
    ("Komedija", "/filmi/komedija"),
    ("Drama", "/filmi/drama"),
    ("Grozljivka", "/filmi/grozljivka"),
    ("Romanca", "/filmi/romanca"),
    ("Kriminalka", "/filmi/kriminalka"),
    ("Družinski", "/filmi/druzinski"),
    ("Dokumentarni", "/filmi/dokumentarni"),
    ("Biografski", "/filmi/biografski"),
    ("Pustolovski", "/filmi/pustolovski"),
    ("Vojni", "/filmi/vojni"),
    ("ZF & Fantazijski", "/filmi/zf-fantazijski"),
]

SERIES_GENRES = [
    ("Vse serije", "/serije"),
    ("VOYO Originali", "/serije/voyo-originali_1"),
    ("Slovenske serije", "/serije/slovenske_1"),
    ("Kriminalne serije", "/serije/kriminalne"),
    ("Komedije", "/serije/komedije"),
    ("Drame", "/serije/drame"),
    ("Balkanske serije", "/serije/balkanske"),
    ("Ameriške serije", "/serije/ameriske_1"),
    ("Evropske serije", "/serije/evropske"),
    ("Turške serije", "/serije/turske"),
    ("Mladinske serije", "/serije/mladinske"),
    ("Dokumentarne serije", "/serije/dokumentarne"),
]

SHOW_GENRES = [
    ("Vse oddaje", "/oddaje"),
    ("VOYO Originali", "/oddaje/voyo-originali"),
    ("Resničnostni šovi", "/oddaje/resnicnostni-sovi"),
    ("Slovenske oddaje", "/oddaje/slovenske"),
    ("Kuharske oddaje", "/oddaje/kuharske"),
    ("Stand-up komedija", "/oddaje/stand-up"),
    ("Zabavne oddaje", "/oddaje/zabavne"),
    ("Informativne oddaje", "/oddaje/informativne-oddaje"),
    ("Otroške oddaje", "/oddaje/otroske"),
]

GENRE_MENUS = {
    "movies": (30101, MOVIE_GENRES, "DefaultMovies.png"),
    "series": (30102, SERIES_GENRES, "DefaultTVShows.png"),
    "shows": (30103, SHOW_GENRES, "DefaultTVShows.png"),
}

# max_resolution setting index -> (max_bandwidth bps for Kodi <= 20, resolution for Kodi 22+)
QUALITY_LIMITS = {1: (8000000, "1920x1080"), 2: (4000000, "1280x720"), 3: (2000000, "1024x576")}


def api():
    return account.get_api()


# ---------------------------------------------------------------------------
# Item rendering
# ---------------------------------------------------------------------------

def item_art(item, fallback=None):
    image, poster = item.get("image"), item.get("poster")
    thumb = resize_image(image, "800xX") if image else resize_image(poster, "500x741")
    thumb = thumb or fallback or ku.ADDON_ICON
    art = {"thumb": thumb, "icon": thumb}
    if image:
        art["landscape"] = resize_image(image, "800xX")
        art["fanart"] = resize_image(image, "1280xX")
    if poster:
        art["poster"] = resize_image(poster, "500x741")
    return art


def bookmark_context(item, group=None):
    """Context menu entries to add/remove an item from 'Moj VOYO' / 'Nadaljuj z ogledom'."""
    key = item.get("bookmark_key") or item.get("media_id") or (
        item.get("uniq") if str(item.get("uniq", "")).startswith("CAT_") else "")
    if not key or not api().is_logged_in():
        return []
    if group == GROUP_MY_VOYO:
        return [(ku.localize(30226), f"RunPlugin({ku.build_url(action='bookmark_remove', id=key, group=group)})")]
    menu = [(ku.localize(30225), f"RunPlugin({ku.build_url(action='bookmark_add', id=key)})")]
    if group == GROUP_CONTINUE:
        menu.append((ku.localize(30228),
                     f"RunPlugin({ku.build_url(action='bookmark_remove', id=key, group=group)})"))
    return menu


def add_content_item(item, group=None, video_type="video"):
    title = item["title"]
    art = item_art(item)
    context = bookmark_context(item, group)
    if item.get("is_series"):
        ku.add_item(title, ku.build_url(action="series", url=item["url"], title=title),
                    art=art, context=context,
                    info={"title": title, "plot": item.get("description"), "mediatype": "tvshow"})
        return
    info = {
        "title": title,
        "plot": item.get("description"),
        "duration": item.get("duration") or None,
        "mediatype": video_type,
    }
    percent, duration = item.get("percent") or 0, item.get("duration") or 0
    if percent and duration and percent < 97:
        info["resume"] = (duration * percent / 100.0, float(duration))
    ku.add_item(title, ku.build_url(action="play", media_id=item["media_id"]),
                is_folder=False, playable=True, art=art, info=info, context=context)


def list_content(items, category, group=None, empty_message=None, video_type="video"):
    items = [i for i in items if i.get("is_series") or i.get("media_id")]
    for item in items:
        add_content_item(item, group, video_type)
    if not items and empty_message:
        ku.notify(empty_message)
    series_count = sum(1 for i in items if i.get("is_series"))
    if items and series_count == len(items):
        content = "tvshows"
    elif not series_count and video_type == "movie":
        content = "movies"
    else:
        content = "videos"
    ku.end_directory(content, category, cache=group is None)


def handle_error(e, category=None):
    ku.log(f"Error: {e}", xbmc.LOGERROR)
    ku.notify_error(str(e))
    ku.end_directory(None, category, succeeded=False)


# ---------------------------------------------------------------------------
# Menus
# ---------------------------------------------------------------------------

def main_menu():
    logged_in = api().is_logged_in()
    entries = []
    if not logged_in:
        entries.append((ku.localize(30112), ku.build_url(action="login"), "DefaultUser.png", False))
    entries += [
        (ku.localize(30100), ku.build_url(action="continue"), "DefaultInProgressShows.png", True),
        (ku.localize(30109), ku.build_url(action="myvoyo"), "DefaultFavourites.png", True),
        (ku.localize(30110), ku.build_url(action="home"), "DefaultRecentlyAddedMovies.png", True),
        (ku.localize(30101), ku.build_url(action="genres", menu="movies"), "DefaultMovies.png", True),
        (ku.localize(30102), ku.build_url(action="genres", menu="series"), "DefaultTVShows.png", True),
        (ku.localize(30103), ku.build_url(action="genres", menu="shows"), "DefaultTVShows.png", True),
        (ku.localize(30105), ku.build_url(action="catalog", cat="/novo", title=ku.localize(30105)),
         "DefaultRecentlyAddedEpisodes.png", True),
        (ku.localize(30106), ku.build_url(action="catalog", cat="/sport", title=ku.localize(30106)),
         "DefaultAddonGame.png", True),
        (ku.localize(30104), ku.build_url(action="live_tv"), "DefaultAddonPVRClient.png", True),
        (ku.localize(30107), ku.build_url(action="search"), "DefaultAddonsSearch.png", True),
        (ku.localize(30111), ku.build_url(action="account"), "DefaultUser.png", True),
    ]
    for label, url, icon, is_folder in entries:
        ku.add_item(label, url, is_folder=is_folder, art={"icon": icon, "thumb": icon})
    ku.end_directory("files", ku.ADDON_NAME, cache=False)


def account_menu():
    a = api()
    user = a.user_data or {}
    if a.is_logged_in():
        ku.add_item(ku.get_setting("account_status"), ku.build_url(action="noop"), is_folder=False,
                    art={"icon": user.get("avatar") or "DefaultUser.png", "thumb": user.get("avatar") or ""})
        profile = ku.get_setting("profile_name")
        ku.add_item(ku.localize(30007) + (f" [{profile}]" if profile else ""),
                    ku.build_url(action="switch_profile"), is_folder=False,
                    art={"icon": "DefaultActor.png"})
        ku.add_item(ku.localize(30004), ku.build_url(action="logout"), is_folder=False,
                    art={"icon": "DefaultIconError.png"})
    else:
        ku.add_item(ku.localize(30112), ku.build_url(action="login"), is_folder=False,
                    art={"icon": "DefaultUser.png"})
    ku.add_item(ku.localize(30108), ku.build_url(action="settings"), is_folder=False,
                art={"icon": "DefaultAddonService.png"})
    ku.end_directory("files", ku.localize(30111), cache=False)


def genre_menu(menu):
    label_id, genres, icon = GENRE_MENUS.get(menu, GENRE_MENUS["movies"])
    for label, path in genres:
        ku.add_item(label, ku.build_url(action="catalog", cat=path, title=label), art={"icon": icon, "thumb": icon})
    ku.end_directory("files", ku.localize(label_id))


def catalog(path, title):
    try:
        items = api().get_catalog(path)
    except VoyoError as e:
        return handle_error(e, title)
    list_content(items, title or ku.ADDON_NAME, empty_message=ku.localize(30229),
                 video_type="movie" if path.startswith("/filmi") else "video")


def home_rows():
    try:
        rows = api().get_home_rows()
    except VoyoError as e:
        return handle_error(e)
    for row in rows:
        first = row["items"][0]
        ku.add_item(row["title"], ku.build_url(action="home_row", id=row["id"]), art=item_art(first),
                    info={"title": row["title"], "plot": ", ".join(i["title"] for i in row["items"][:8])})
    ku.end_directory("files", ku.localize(30110))


def home_row(row_id):
    try:
        row = next((r for r in api().get_home_rows() if r["id"] == row_id), None)
    except VoyoError as e:
        return handle_error(e)
    if not row:
        return ku.end_directory(None, succeeded=False)
    list_content(row["items"], row["title"])


def bookmarks(group):
    category = ku.localize(30100 if group == GROUP_CONTINUE else 30109)
    if not account.ensure_session():
        return ku.end_directory(None, category, succeeded=False)
    try:
        items = api().get_bookmarks(group)
    except VoyoError as e:
        return handle_error(e, category)
    if not items:
        ku.add_item(ku.localize(30229), ku.build_url(action="noop"), is_folder=False)
    list_content(items, category, group=group)


def series(url, title):
    try:
        details = api().get_series_details(url)
    except VoyoError as e:
        return handle_error(e, title)
    title = details.get("title") or title
    seasons = details.get("seasons") or []
    image = details.get("image")
    if len(seasons) == 1:
        return season(details.get("category_id"), seasons[0]["name"], title, image)
    for s in seasons:
        ku.add_item(s["name"], ku.build_url(action="season", cid=details.get("category_id"), season=s["name"],
                                            title=title, img=image),
                    art=item_art({"image": image}),
                    info={"title": s["name"], "tvshowtitle": title, "plot": details.get("description"),
                          "mediatype": "season"})
    if not seasons:
        ku.notify(ku.localize(30229))
    ku.end_directory("seasons", title)


def season(category_id, season_name, series_title, series_image=""):
    category = f"{series_title} - {season_name}" if season_name else series_title
    try:
        episodes = api().get_season_episodes(category_id, season_name)
    except VoyoError as e:
        return handle_error(e, category)
    for ep in episodes:
        art = item_art({"image": ep.get("image") or series_image})
        if series_image:
            art["fanart"] = resize_image(series_image, "1280xX")
        ku.add_item(ep["title"], ku.build_url(action="play", media_id=ep["media_id"]), is_folder=False,
                    playable=True, art=art, context=bookmark_context(ep),
                    info={"title": ep["title"], "tvshowtitle": series_title, "plot": ep.get("description"),
                          "duration": ep.get("duration") or None, "season": ep.get("season") or None,
                          "episode": ep.get("episode") or None, "mediatype": "episode"})
    if not episodes:
        ku.notify(ku.localize(30229))
    ku.end_directory("episodes", category)


def live_tv():
    for ch in LIVE_CHANNELS:
        ku.add_item(ch["name"], ku.build_url(action="play_live", channel=ch["id"]), is_folder=False,
                    playable=True, art={"icon": ch["icon"], "thumb": ch["icon"]},
                    info={"title": ch["name"], "plot": ch["description"], "mediatype": "video"})
    ku.end_directory("videos", ku.localize(30104))


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search_menu():
    ku.add_item(ku.localize(30113), ku.build_url(action="search_new"), art={"icon": "DefaultAddonsSearch.png"})
    for query in ku.load_json(SEARCH_HISTORY_FILE, []):
        ku.add_item(query, ku.build_url(action="search_results", q=query), art={"icon": "DefaultAddonsSearch.png"},
                    context=[(ku.localize(30230), f"RunPlugin({ku.build_url(action='search_remove', q=query)})"),
                             (ku.localize(30114), f"RunPlugin({ku.build_url(action='search_clear')})")])
    ku.end_directory("files", ku.localize(30107), cache=False)


def search_new():
    query = xbmcgui.Dialog().input(ku.localize(30206), type=xbmcgui.INPUT_ALPHANUM).strip()
    ku.end_directory(None, succeeded=False)
    if not query:
        return
    history = [q for q in ku.load_json(SEARCH_HISTORY_FILE, []) if q.lower() != query.lower()]
    ku.save_json(SEARCH_HISTORY_FILE, ([query] + history)[:SEARCH_HISTORY_SIZE])
    # Navigate to a stable results URL so "back" doesn't pop the keyboard up again
    xbmc.executebuiltin(f"Container.Update({ku.build_url(action='search_results', q=query)})")


def search_results(query):
    category = f"{ku.localize(30107)}: {query}"
    try:
        items = api().search(query)
    except VoyoError as e:
        return handle_error(e, category)
    list_content(items, category, empty_message=ku.localize(30207))


def search_remove(query):
    ku.save_json(SEARCH_HISTORY_FILE, [q for q in ku.load_json(SEARCH_HISTORY_FILE, []) if q != query])
    xbmc.executebuiltin("Container.Refresh")


def search_clear():
    ku.delete_file(SEARCH_HISTORY_FILE)
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------------------------
# Bookmarks actions
# ---------------------------------------------------------------------------

def bookmark_add(item_id):
    if not account.ensure_session():
        return
    try:
        api().add_bookmark(item_id, GROUP_MY_VOYO)
        ku.notify(ku.localize(30223))
    except VoyoError as e:
        ku.notify_error(str(e))


def bookmark_remove(item_id, group):
    if not account.ensure_session():
        return
    try:
        api().remove_bookmark(item_id, group or GROUP_MY_VOYO)
        ku.notify(ku.localize(30224))
        xbmc.executebuiltin("Container.Refresh")
    except VoyoError as e:
        ku.notify_error(str(e))


# ---------------------------------------------------------------------------
# Playback
# ---------------------------------------------------------------------------

def resolve_failed():
    xbmcplugin.setResolvedUrl(ku.HANDLE, False, xbmcgui.ListItem())


def check_inputstream(manifest_type):
    try:
        from inputstreamhelper import Helper
    except ImportError:
        return True
    return Helper(manifest_type, drm="com.widevine.alpha").check_inputstream()


def _resolve_stream(resolver, *args):
    """Calls an API stream resolver, recovering once from an expired session."""
    try:
        return resolver(*args)
    except TooManyDevicesError:
        account.get_api().clear_session()
        account.update_status_settings(account.get_api())
        xbmcgui.Dialog().ok(ku.ADDON_NAME, ku.localize(30204, "voyo.si/nastavitve/naprave"))
    except VoyoError as e:
        if e.is_auth_error and account.ensure_session(force_refresh=True):
            try:
                return resolver(*args)
            except VoyoError as e2:
                e = e2
        ku.log(f"Stream error: {e} ({e.code})", xbmc.LOGERROR)
        ku.notify_error(str(e) or ku.localize(30203))
    return None


def build_play_item(stream):
    li = xbmcgui.ListItem(path=stream["url"], offscreen=True)
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setMimeType("application/dash+xml" if stream["manifest_type"] == "mpd" else "application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    if ku.KODI_VERSION < 21:
        li.setProperty("inputstream.adaptive.manifest_type", stream["manifest_type"])

    if stream.get("is_drm"):
        if ku.KODI_VERSION >= 22:
            li.setProperty("inputstream.adaptive.drm_legacy",
                           f"com.widevine.alpha|{stream['license_url']}|{stream['license_headers']}")
        else:
            li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
            li.setProperty("inputstream.adaptive.license_key",
                           f"{stream['license_url']}|{stream['license_headers']}|b|")

    limit = QUALITY_LIMITS.get(ku.get_setting_int("max_resolution"))
    if limit:
        if ku.KODI_VERSION <= 20:
            li.setProperty("inputstream.adaptive.max_bandwidth", str(limit[0]))
        elif ku.KODI_VERSION >= 22:
            li.setProperty("inputstream.adaptive.config", json.dumps({"resolution_limit": limit[1]}))
    return li


def play(media_id):
    if not account.ensure_session() or not check_inputstream("mpd"):
        return resolve_failed()
    stream = _resolve_stream(api().get_video_stream, media_id)
    if not stream:
        return resolve_failed()
    xbmcplugin.setResolvedUrl(ku.HANDLE, True, build_play_item(stream))


def play_live(channel):
    if not account.ensure_session() or not check_inputstream("hls"):
        return resolve_failed()
    stream = _resolve_stream(api().get_live_stream, channel)
    if not stream:
        return resolve_failed()
    xbmcplugin.setResolvedUrl(ku.HANDLE, True, build_play_item(stream))


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def run():
    params = ku.parse_params()
    action = params.get("action", "")
    ku.log(f"Action '{action}' params {params}")

    routes = {
        "": main_menu,
        "root": main_menu,
        "account": account_menu,
        "genres": lambda: genre_menu(params.get("menu", "movies")),
        "catalog": lambda: catalog(params.get("cat", ""), params.get("title", "")),
        "home": home_rows,
        "home_row": lambda: home_row(params.get("id", "")),
        "continue": lambda: bookmarks(GROUP_CONTINUE),
        "myvoyo": lambda: bookmarks(GROUP_MY_VOYO),
        "series": lambda: series(params.get("url", ""), params.get("title", "")),
        "season": lambda: season(params.get("cid"), params.get("season", ""), params.get("title", ""),
                                 params.get("img", "")),
        "live_tv": live_tv,
        "search": search_menu,
        "search_new": search_new,
        "search_results": lambda: search_results(params.get("q", "")),
        "search_remove": lambda: search_remove(params.get("q", "")),
        "search_clear": search_clear,
        "play": lambda: play(params.get("media_id", "")),
        "play_live": lambda: play_live(params.get("channel", "")),
        "bookmark_add": lambda: bookmark_add(params.get("id", "")),
        "bookmark_remove": lambda: bookmark_remove(params.get("id", ""), params.get("group")),
        "login": lambda: account.login_flow() and xbmc.executebuiltin("Container.Refresh"),
        "logout": account.logout_flow,
        "switch_profile": account.choose_profile,
        "reset_device": account.reset_device,
        "clear_cache": clear_cache,
        "settings": ku.ADDON.openSettings,
        "noop": lambda: None,
    }
    handler = routes.get(action)
    if handler is None:
        ku.log(f"Unknown action: {action}", xbmc.LOGWARNING)
        handler = main_menu
    handler()


def clear_cache():
    ku.delete_file(SEARCH_HISTORY_FILE)
    ku.notify(ku.localize(30222))
