# -*- coding: utf-8 -*-
"""Small Kodi helpers shared by the plugin modules."""

import json
import os
import platform
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_VERSION = ADDON.getAddonInfo("version")
ADDON_ICON = ADDON.getAddonInfo("icon")
ADDON_FANART = ADDON.getAddonInfo("fanart")
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

BASE_URL = sys.argv[0] if sys.argv and sys.argv[0].startswith("plugin://") else f"plugin://{ADDON_ID}/"
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1


def kodi_major_version():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    except ValueError:
        return 19


KODI_VERSION = kodi_major_version()


def log(msg, level=xbmc.LOGDEBUG):
    if level == xbmc.LOGDEBUG and get_setting_bool("debug"):
        level = xbmc.LOGINFO
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def localize(string_id, *args):
    text = ADDON.getLocalizedString(string_id)
    return text % args if args else text


def get_setting(key, default=""):
    try:
        return ADDON.getSetting(key) or default
    except RuntimeError:
        return default


def get_setting_bool(key):
    return get_setting(key).lower() == "true"


def get_setting_int(key, default=0):
    try:
        return int(get_setting(key, str(default)))
    except ValueError:
        return default


def set_setting(key, value):
    if isinstance(value, bool):
        value = "true" if value else "false"
    ADDON.setSetting(key, str(value))


def build_url(**query):
    return BASE_URL + "?" + urllib.parse.urlencode({k: v for k, v in query.items() if v not in (None, "")})


def parse_params(argv=None):
    argv = argv or sys.argv
    if len(argv) > 2 and argv[2]:
        return dict(urllib.parse.parse_qsl(argv[2].lstrip("?")))
    return {}


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, time_ms)


def notify_error(message):
    notify(message, xbmcgui.NOTIFICATION_ERROR, 6000)


def device_name():
    """The name shown in the VOYO device list (setting, or 'Kodi (<friendly name>)')."""
    name = get_setting("device_name").strip()
    if name:
        return name
    friendly = xbmc.getInfoLabel("System.FriendlyName").strip()
    return f"Kodi ({friendly})" if friendly and friendly.lower() != "kodi" else "Kodi"


def device_model():
    system = platform.system() or "Unknown"
    if xbmc.getCondVisibility("System.Platform.Android"):
        system = "Android"
    elif xbmc.getCondVisibility("System.Platform.Linux.RaspberryPi"):
        system = "Raspberry Pi"
    return f"Kodi {KODI_VERSION} ({system})"


# ---------------------------------------------------------------------------
# ListItem helpers
# ---------------------------------------------------------------------------

def set_video_info(list_item, info):
    """Sets video metadata using InfoTagVideo on Kodi 20+ and setInfo on Kodi 19."""
    resume = info.pop("resume", None)
    if KODI_VERSION >= 20:
        tag = list_item.getVideoInfoTag()
        setters = {
            "title": tag.setTitle,
            "plot": tag.setPlot,
            "tvshowtitle": tag.setTvShowTitle,
            "mediatype": tag.setMediaType,
            "duration": lambda v: tag.setDuration(int(v)),
            "season": lambda v: tag.setSeason(int(v)),
            "episode": lambda v: tag.setEpisode(int(v)),
            "year": lambda v: tag.setYear(int(v)),
        }
        for key, value in info.items():
            if value not in (None, "") and key in setters:
                setters[key](value)
        if resume:
            tag.setResumePoint(resume[0], resume[1])
    else:
        list_item.setInfo("video", {k: v for k, v in info.items() if v not in (None, "")})
        if resume:
            list_item.setProperty("ResumeTime", str(resume[0]))
            list_item.setProperty("TotalTime", str(resume[1]))


def add_item(label, url, is_folder=True, art=None, info=None, playable=False, context=None, label2=None):
    li = xbmcgui.ListItem(label=label, label2=label2 or "", offscreen=True)
    art = dict(art or {})
    art.setdefault("fanart", ADDON_FANART)
    li.setArt(art)
    if info:
        set_video_info(li, dict(info))
    if playable:
        li.setProperty("IsPlayable", "true")
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


def end_directory(content="videos", category=None, succeeded=True, cache=True, update=False):
    if category:
        xbmcplugin.setPluginCategory(HANDLE, category)
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded, updateListing=update, cacheToDisc=cache)


# ---------------------------------------------------------------------------
# Small JSON store in the profile folder (search history)
# ---------------------------------------------------------------------------

def load_json(name, default):
    try:
        with open(os.path.join(PROFILE_DIR, name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(name, data):
    os.makedirs(PROFILE_DIR, exist_ok=True)
    with open(os.path.join(PROFILE_DIR, name), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


def delete_file(name):
    try:
        os.remove(os.path.join(PROFILE_DIR, name))
    except OSError:
        pass
