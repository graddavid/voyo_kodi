# -*- coding: utf-8 -*-
"""Login, logout, profile and device handling (dialogs + session upkeep)."""

import time

import xbmc
import xbmcgui

from resources.lib import kodiutils as ku
from resources.lib.voyo_api import (
    DEVICES_URL, TV_PAIR_URL, NotLoggedInError, TooManyDevicesError, VoyoApi, VoyoError,
)

TV_CODE_POLL_SECONDS = 3
TV_CODE_REFRESH_SECONDS = 5 * 60
TV_CODE_TIMEOUT_SECONDS = 15 * 60

_API = None


def get_api():
    global _API
    if _API is None:
        _API = VoyoApi(
            data_dir=ku.PROFILE_DIR,
            logger=lambda msg: ku.log(msg),
            device_name=ku.device_name(),
            device_model=ku.device_model(),
        )
        if ku.get_setting("device_id_display") != _API.device_id:
            ku.set_setting("device_id_display", _API.device_id)
        if ku.get_setting_bool("logged_in") != _API.is_logged_in():
            update_status_settings(_API)
    return _API


def update_status_settings(api):
    user = api.user_data or {}
    if api.is_logged_in():
        name = user.get("nickname") or user.get("email") or "?"
        status = ku.localize(30115, name)
        until = (user.get("subscriptionUntil") or "")[:10]
        if until:
            status += " · " + ku.localize(30116, until)
        elif user.get("isSubscribed") is False:
            status += " · " + ku.localize(30205)
    else:
        status = ku.localize(30118)
    ku.set_setting("account_status", status)
    ku.set_setting("logged_in", api.is_logged_in())


def _show_too_many_devices():
    xbmcgui.Dialog().ok(ku.ADDON_NAME, ku.localize(30204, DEVICES_URL))


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

def login_flow():
    """Interactive login. Returns True when logged in."""
    api = get_api()
    choice = xbmcgui.Dialog().select(ku.localize(30208), [ku.localize(30209), ku.localize(30210)])
    if choice < 0:
        return False
    try:
        ok = login_with_code(api) if choice == 0 else login_with_password(api)
    except TooManyDevicesError:
        api.clear_session()
        update_status_settings(api)
        _show_too_many_devices()
        return False
    except VoyoError as e:
        ku.log(f"Login failed: {e} ({e.code})", xbmc.LOGERROR)
        update_status_settings(api)
        xbmcgui.Dialog().ok(ku.ADDON_NAME, f"{ku.localize(30201)}\n{e}")
        return False
    if not ok:
        return False
    choose_profile(api, only_if_multiple=True)
    update_status_settings(api)
    user = api.user_data
    ku.notify(ku.localize(30227, user.get("nickname") or user.get("email") or ""))
    return True


def login_with_code(api):
    """Shows a pairing code and waits until the user confirms it on voyo.si."""
    progress = xbmcgui.DialogProgress()
    started = time.time()
    code, code_time = api.request_tv_code(), time.time()
    progress.create(ku.localize(30209), "")
    try:
        while not progress.iscanceled():
            now = time.time()
            if now - started > TV_CODE_TIMEOUT_SECONDS:
                xbmcgui.Dialog().ok(ku.ADDON_NAME, ku.localize(30213))
                return False
            if now - code_time > TV_CODE_REFRESH_SECONDS:
                code, code_time = api.request_tv_code(), now
            remaining = int(TV_CODE_REFRESH_SECONDS - (now - code_time))
            percent = int(100 * remaining / TV_CODE_REFRESH_SECONDS)
            progress.update(percent, "{}\n\n[B][COLOR FF8A5CF6]{}[/COLOR][/B]\n{}".format(
                ku.localize(30211, TV_PAIR_URL), "  ".join(code), ku.localize(30212)))
            if api.poll_tv_login():
                return True
            if xbmc.Monitor().waitForAbort(TV_CODE_POLL_SECONDS):
                return False
    finally:
        progress.close()
    return False


def login_with_password(api, email=None, password=None):
    dialog = xbmcgui.Dialog()
    if email is None:
        email = dialog.input(ku.localize(30214), ku.get_setting("email"), type=xbmcgui.INPUT_ALPHANUM)
        if not email:
            return False
    if password is None:
        password = dialog.input(ku.localize(30215), type=xbmcgui.INPUT_ALPHANUM,
                                option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return False
    api.login(email, password)
    ku.set_setting("email", email.strip())
    ku.set_setting("password", password if ku.get_setting_bool("remember_password") else "")
    return True


def _silent_relogin(api):
    """Logs in again with saved credentials (same device id -> same device slot)."""
    email, password = ku.get_setting("email"), ku.get_setting("password")
    if not (email and password):
        return False
    try:
        api.login(email, password)
        update_status_settings(api)
        return True
    except TooManyDevicesError:
        api.clear_session()
        _show_too_many_devices()
    except VoyoError as e:
        ku.log(f"Automatic login failed: {e}", xbmc.LOGWARNING)
    return False


def ensure_session(interactive=True, force_refresh=False):
    """Makes sure there is a valid session. Returns True if logged in."""
    api = get_api()
    if api.is_logged_in():
        try:
            api.refresh_session(force=force_refresh)
            return True
        except TooManyDevicesError:
            api.clear_session()
            update_status_settings(api)
            _show_too_many_devices()
            return False
        except (NotLoggedInError, VoyoError) as e:
            ku.log(f"Session no longer valid: {e}", xbmc.LOGINFO)
            update_status_settings(api)
            if _silent_relogin(api):
                return True
            if interactive:
                ku.notify(ku.localize(30220), xbmcgui.NOTIFICATION_WARNING)
                return login_flow()
            return False

    if _silent_relogin(api):
        return True
    if interactive and xbmcgui.Dialog().yesno(ku.ADDON_NAME, ku.localize(30202)):
        return login_flow()
    return False


# ---------------------------------------------------------------------------
# Logout, profiles, device
# ---------------------------------------------------------------------------

def logout_flow():
    api = get_api()
    if not api.is_logged_in():
        ku.notify(ku.localize(30118))
        return
    choice = xbmcgui.Dialog().yesnocustom(
        ku.localize(30216), ku.localize(30217),
        customlabel=ku.localize(30250), nolabel=ku.localize(30251), yeslabel=ku.localize(30252))
    if choice not in (0, 1):  # -1 = cancelled, 2 = custom "Cancel"
        return
    api.logout(remove_device=(choice == 1))
    ku.set_setting("password", "")
    update_status_settings(api)
    ku.notify(ku.localize(30218))
    xbmc.executebuiltin("Container.Refresh")


def choose_profile(api=None, only_if_multiple=False):
    api = api or get_api()
    if not api.is_logged_in():
        ku.notify(ku.localize(30118))
        return
    try:
        profiles = api.get_profiles()
    except VoyoError as e:
        ku.log(f"Profiles unavailable: {e}", xbmc.LOGWARNING)
        return
    if not profiles or (only_if_multiple and len(profiles) < 2):
        _store_profile_name(api, profiles)
        return
    current = api.user_data.get("profileId")
    items = []
    for p in profiles:
        li = xbmcgui.ListItem(p.get("name") or "?")
        if p.get("avatar"):
            li.setArt({"thumb": p["avatar"], "icon": p["avatar"]})
        items.append(li)
    preselect = next((i for i, p in enumerate(profiles) if p.get("profileId") == current), -1)
    idx = xbmcgui.Dialog().select(ku.localize(30219), items, useDetails=True, preselect=preselect)
    if idx < 0:
        return
    try:
        api.switch_profile(profiles[idx]["profileId"])
    except VoyoError as e:
        ku.notify_error(str(e))
        return
    _store_profile_name(api, profiles)
    update_status_settings(api)
    xbmc.executebuiltin("Container.Refresh")


def _store_profile_name(api, profiles):
    current = api.user_data.get("profileId")
    name = next((p.get("name") for p in profiles or [] if p.get("profileId") == current), "")
    ku.set_setting("profile_name", name or "")


def reset_device():
    if not xbmcgui.Dialog().yesno(ku.ADDON_NAME, ku.localize(30221)):
        return
    api = get_api()
    api.logout(remove_device=True)
    api.reset_device_id()
    ku.set_setting("device_id_display", api.device_id)
    update_status_settings(api)
    ku.notify(ku.localize(30218))
