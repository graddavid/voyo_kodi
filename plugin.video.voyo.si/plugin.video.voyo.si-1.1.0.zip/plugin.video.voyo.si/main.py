# -*- coding: utf-8 -*-
"""VOYO.si Kodi video add-on entry point."""

from resources.lib import plugin

if __name__ == "__main__":
    plugin.run()
