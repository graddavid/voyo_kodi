# VOYO.si Kodi Video Add-on (`plugin.video.voyo.si`)

Neuradni vtičnik za medijski predvajalnik **Kodi** (različice 19 Matrix, 20 Nexus, 21 Omega, 22 Piers), ki omogoča ogled vseh vsebin s platforme **VOYO.si** z vašim obstoječim naročniškim računom.

---

## 🚀 Glavne funkcije

- **Popolna podpora za naročniški račun**:
  - Enostaven vnos e-pošte in gesla v nastavitvah dodatka.
  - Varna avtentikacija neposredno prek uradnega Voyo GraphQL API (`gql.voyo.si`).
  - Samodejno shranjevanje seje in povezovanje naprave (`Kodi Media Center`).
- **Bogata zbirka vsebin**:
  - **Filmi**: Vsi filmi, slovenski, kratki, akcija, komedija, drama, grozljivka, romanca, kriminalka, družinski, dokumentarni, vojni, ZF in drugi.
  - **Serije**: Pregled serij po žanrih (VOYO originali, slovenske, kriminalne, komedije, balkanske, tuje), z izbiro sezon in vseh posameznih epizod.
  - **Oddaje**: Kuharske, resničnostni šovi, stand-up, zabavne in informativne oddaje.
  - **TV v živo**: Vseh 6 programov skupine Pro Plus (**POP TV**, **Kanal A**, **KINO**, **BRIO**, **OTO**, **VOYO TV**).
  - **Nadaljuj z ogledom (Continue Watching)**: Neposreden dostop do začetih vsebin.
  - **Iskalnik**: Hitro iskanje po naslovih filmov in serij.
- **Predvajanje z Widevine DRM**:
  - Predvajanje DASH MPD tokov z zaščito Widevine prek dodatka `inputstream.adaptive`.
  - Nastavitev želene ločljivosti (Samodejno / 1080p Full HD / 720p HD / 576p SD).

---

## 📦 Namestitev v Kodi

### 1. korak: Omogočite neznane vire v Kodi
1. V Kodiju odprite **Settings (Nastavitve)** ⚙️ -> **System (Sistem)** -> **Add-ons (Dodatki)**.
2. Vključite možnost **Unknown sources (Neznani viri)**.

### 2. korak: Namestite `InputStream Adaptive`
1. V Kodiju pojdite na **Add-ons (Dodatki)** -> **Install from repository**.
2. Izberite **Kodi Add-on repository** -> **Video Player InputStream**.
3. Poiščite **InputStream Adaptive** in kliknite **Install** (ali **Enable**, če je že nameščen).

### 3. korak: Namestitev dodatka VOYO.si
1. Datoteko `plugin.video.voyo.si.zip` skopirajte na napravo s Kodijem (ali jo namestite neposredno iz te mape).
2. V Kodiju pojdite na **Add-ons (Dodatki)** -> ikona škatle 📦 v zgornjem levem kotu -> **Install from zip file (Namesti iz datoteke zip)**.
3. Poiščite in izberite `plugin.video.voyo.si.zip`.
4. Počakajte nekaj sekund, da se v zgornjem desnem kotu izpiše: *VOYO.si Add-on installed*.

---

## 🔑 Prijava z vašim računom

1. Pojdite na **Add-ons** -> **Video add-ons** -> z desnim klikom (ali daljšim pritiskom) na **VOYO.si** izberite **Settings (Nastavitve)**.
2. V zavihku **Uporabniški račun**:
   - Vnesite vaš **E-poštni naslov**.
   - Vnesite vaše **Geslo**.
3. Kliknite **Preizkusi prijavo**. Ob uspešni prijavi se izpiše obvestilo z vašim uporabniškim imenom.
4. Kliknite **OK** in odprite dodatek!

---

## 💡 Opombe glede Widevine CDM

- Ob prvem predvajanju zaščitenega videa vas bo Kodi / InputStream Adaptive morda vprašal za prenos knjižnice **Widevine CDM**. Potrdite prenos (`I Agree / Download`).
- Na napravah **Android / Google TV** je Widevine podpora že vgrajena v sam sistem.
- Na **Windows / Mac / Linux / LibreELEC** bo InputStream Adaptive samodejno prenesel potrebno Widevine knjižnico.
