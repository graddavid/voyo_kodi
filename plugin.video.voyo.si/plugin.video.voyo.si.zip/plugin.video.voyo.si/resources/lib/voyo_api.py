# -*- coding: utf-8 -*-
"""
VOYO.si API Client
Handles authentication with Voyo GraphQL API, session management,
catalog parsing (movies, series, episodes, shows), and stream resolution for Kodi.
"""

import os
import re
import json
import uuid
import urllib.request
import urllib.parse
import urllib.error
from html import unescape

GQL_URL = "https://gql.voyo.si/v2"
BASE_URL = "https://voyo.si"
DEFAULT_WV_LICENSE = "https://wv-ksm.api.24ur.si"
SITE_ID = 30005

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

# Live TV channel mapping for Pro Plus
LIVE_CHANNELS = [
    {
        "id": "POPTV",
        "name": "POP TV",
        "description": "Najbolj gledan slovenski televizijski program.",
        "icon": "https://assets.24ur.si/voyo/channels/poptv.png"
    },
    {
        "id": "KANALA",
        "name": "Kanal A",
        "description": "Akcija, filmi, šport in zabava.",
        "icon": "https://assets.24ur.si/voyo/channels/kanala.png"
    },
    {
        "id": "POPKINO",
        "name": "KINO",
        "description": "Najboljši filmi 24 ur na dan.",
        "icon": "https://assets.24ur.si/voyo/channels/kino.png"
    },
    {
        "id": "POPBRIO",
        "name": "BRIO",
        "description": "Komične nanizanke, priljubljene serije in zabavne oddaje.",
        "icon": "https://assets.24ur.si/voyo/channels/brio.png"
    },
    {
        "id": "POPOTO",
        "name": "OTO",
        "description": "Prvi slovenski otroški program s sinhroniziranimi risankami.",
        "icon": "https://assets.24ur.si/voyo/channels/oto.png"
    },
    {
        "id": "VOYO",
        "name": "VOYO TV",
        "description": "Izbor vrhunskih VOYO vsebin in športnih prenosov.",
        "icon": "https://assets.24ur.si/voyo/channels/voyo.png"
    }
]


def parse_iso_duration(duration_str):
    """Converts ISO 8601 duration (e.g. PT1H33M55S) to total seconds."""
    if not duration_str or not duration_str.startswith("PT"):
        return 0
    pattern = r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?"
    match = re.match(pattern, duration_str)
    if not match:
        return 0
    hours = int(match.group(1) or 0)
    minutes = int(match.group(2) or 0)
    seconds = int(match.group(3) or 0)
    return hours * 3600 + minutes * 60 + seconds


def parse_time_duration(time_str):
    """Converts MM:SS or HH:MM:SS to total seconds."""
    if not time_str:
        return 0
    parts = time_str.strip().split(":")
    try:
        if len(parts) == 2:
            return int(parts[0]) * 60 + int(parts[1])
        elif len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    except (ValueError, TypeError):
        pass
    return 0


def normalize_content_url(url):
    """
    Ensures relative and absolute URLs for series/shows/movies
    point to /vsebina/<slug> where Voyo actually hosts the pages.
    """
    if not url:
        return ""
    if url.startswith("https://voyo.si"):
        path = url[len("https://voyo.si"):]
        if not path.startswith("/vsebina/") and not path.startswith("/filmi") and not path.startswith("/serije") and not path.startswith("/oddaje"):
            return "https://voyo.si/vsebina" + path
        return url
    elif url.startswith("/"):
        if not url.startswith("/vsebina/") and not url.startswith("/filmi") and not url.startswith("/serije") and not path_is_special(url):
            return "/vsebina" + url
        return url
    return url


def path_is_special(path):
    return any(path.startswith(prefix) for prefix in ["/filmi", "/serije", "/oddaje", "/novo", "/sport", "/iskanje", "/info"])


class VoyoApi:
    def __init__(self, data_dir=None, logger=None):
        self.data_dir = data_dir or os.path.expanduser("~")
        self.token_file = os.path.join(self.data_dir, "voyo_session.json")
        self.logger = logger or (lambda msg: None)
        self.token = ""
        self.device_id = ""
        self.user_data = {}
        self._load_session()

    def _load_session(self):
        """Loads cached JWT token, device ID and user details."""
        if os.path.exists(self.token_file):
            try:
                with open(self.token_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.token = data.get("token", "")
                    self.device_id = data.get("device_id", "")
                    self.user_data = data.get("user_data", {})
            except Exception as e:
                self.logger(f"Error loading session: {e}")

        if not self.device_id:
            self.device_id = str(uuid.uuid4())
            self._save_session()

    def _save_session(self):
        """Saves current session to disk."""
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            with open(self.token_file, "w", encoding="utf-8") as f:
                json.dump({
                    "token": self.token,
                    "device_id": self.device_id,
                    "user_data": self.user_data
                }, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.logger(f"Error saving session: {e}")

    def clear_session(self):
        """Clears user session and token."""
        self.token = ""
        self.user_data = {}
        if os.path.exists(self.token_file):
            try:
                os.remove(self.token_file)
            except Exception:
                pass

    def is_logged_in(self):
        return bool(self.token)

    def fetch_gql(self, query, variables=None, timeout=15):
        """Executes a GraphQL query against gql.voyo.si."""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
            "Onl-Location": "https://voyo.si/",
            "Origin": "https://voyo.si",
            "Referer": "https://voyo.si/",
            "Device-Id": self.device_id,
        }
        if self.token:
            headers["Authorization"] = self.token

        payload = {"query": query, "variables": variables or {}}
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(GQL_URL, data=data, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp_data = resp.read().decode("utf-8")
                res = json.loads(resp_data)
                if "errors" in res and res["errors"]:
                    err_msg = res["errors"][0].get("message", "GQL Error")
                    # Check for localized message
                    ext = res["errors"][0].get("extensions", {}).get("message", {})
                    if isinstance(ext, dict) and "tMessage" in ext:
                        err_msg = ext["tMessage"]
                    raise Exception(err_msg)
                return res.get("data", {})
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")
            self.logger(f"GQL HTTP Error {e.code}: {err_body}")
            raise Exception(f"HTTP Napaka {e.code}: {e.reason}")
        except urllib.error.URLError as e:
            self.logger(f"GQL URL Error: {e.reason}")
            raise Exception(f"Napaka povezave: {e.reason}")

    def login(self, email, password):
        """Authenticates with email and password via GraphQL."""
        query = """
        query loginUser($email: String!, $siteId: Int!, $password: String!) {
            login(email: $email, siteId: $siteId, password: $password) {
                id token email avatar nickname
                deviceId profileId status subscriptionUntil
                profileType isSubscribed
            }
        }
        """
        variables = {
            "email": email.strip(),
            "password": password.strip(),
            "siteId": SITE_ID
        }

        data = self.fetch_gql(query, variables)
        user_info = data.get("login")
        if not user_info or not user_info.get("token"):
            raise Exception("Prijava ni uspela. Preverite podatke.")

        self.token = user_info.get("token")
        self.user_data = user_info

        # Register / link device
        try:
            self.link_device()
        except Exception as e:
            self.logger(f"Device linking warning: {e}")

        self._save_session()
        return self.user_data

    def link_device(self):
        """Links device to user account."""
        query = """
        query LinkDeviceToUser($deviceFamily: String!, $deviceName: String!, $deviceModel: String!) {
            linkDeviceToUser(
                deviceFamily: $deviceFamily
                deviceName: $deviceName
                deviceModel: $deviceModel
            ) {
                id token email avatar nickname
                deviceId profileId status subscriptionUntil
                profileType isSubscribed
            }
        }
        """
        variables = {
            "deviceFamily": "PC",
            "deviceName": "Kodi",
            "deviceModel": "Kodi Media Center"
        }
        data = self.fetch_gql(query, variables)
        if data.get("linkDeviceToUser"):
            self.user_data = data["linkDeviceToUser"]
            if self.user_data.get("token"):
                self.token = self.user_data["token"]
            self._save_session()
        return self.user_data

    def get_bookmarks(self):
        """Fetches continue watching items."""
        if not self.token:
            return []
        query = """
        query voyoBookmarks {
            voyoBookmark {
                groups {
                    id name
                    items {
                        entityId categoryId
                        data { percent duration }
                    }
                }
            }
        }
        """
        try:
            data = self.fetch_gql(query)
            groups = data.get("voyoBookmark", {}).get("groups", [])
            bookmarks = []
            for g in groups:
                for item in g.get("items", []):
                    bookmarks.append({
                        "media_id": item.get("entityId"),
                        "category_id": item.get("categoryId"),
                        "percent": item.get("data", {}).get("percent", 0),
                        "duration": item.get("data", {}).get("duration", 0)
                    })
            return bookmarks
        except Exception as e:
            self.logger(f"Error fetching bookmarks: {e}")
            return []

    def get_video_stream(self, media_id):
        """
        Resolves DASH MPD video stream and Widevine DRM license parameters.
        Returns:
            {
                'url': manifest_url,
                'is_drm': bool,
                'license_url': license_url,
                'license_headers': headers_string,
                'info': info_message
            }
        """
        if not media_id:
            raise Exception("ID videa ni bil določen.")

        query = """
        query VideoUrlV2($id: Int!, $siteId: Int) {
            videoUrlV2 (
                id: $id
                siteId: $siteId
            ) {
                url info infoCode license
            }
        }
        """
        variables = {
            "id": int(str(media_id).strip()),
            "siteId": SITE_ID
        }

        data = self.fetch_gql(query, variables)
        video_res = data.get("videoUrlV2")
        if not video_res:
            raise Exception("Strežnik ni vrnil podatkov o videu.")

        info_code = video_res.get("infoCode", 0)
        info_msg = video_res.get("info", "")

        if info_code == 503 or info_code == 507:
            raise Exception(info_msg or "Vsebine ni mogoče predvajati. Naročnina ni aktivna.")
        elif info_code != 0:
            self.logger(f"Video stream infoCode {info_code}: {info_msg}")

        stream_url = video_res.get("url")
        if not stream_url or "NOVIDEO" in stream_url:
            raise Exception(info_msg or "Video tok ni na voljo ali pa je prišlo do napake z dostopom.")

        license_url = video_res.get("license") or DEFAULT_WV_LICENSE
        is_dash = ".mpd" in stream_url or "application/dash+xml" in stream_url

        # Widevine license header: X-DRM-Message contains the exact stream URL
        encoded_stream_url = urllib.parse.quote(stream_url, safe="")
        license_headers = f"Content-Type=application/octet-stream&X-DRM-Message={encoded_stream_url}"

        return {
            "url": stream_url,
            "is_drm": True,
            "manifest_type": "mpd" if is_dash else "hls",
            "license_type": "com.widevine.alpha",
            "license_url": license_url,
            "license_headers": license_headers,
            "info": info_msg
        }

    def get_live_stream(self, channel_code):
        """
        Resolves Live TV HLS stream URL for a Pro Plus channel.
        channel_code: POPTV, KANALA, POPKINO, POPBRIO, POPOTO, VOYO
        """
        query = """
        query EpgHlsUrlV2($channel: String!, $chunkStart: Int!, $chunkEnd: Int!) {
            epgHlsUrlV2 (
                channel: $channel
                chunkStart: $chunkStart
                chunkEnd: $chunkEnd
            ) {
                url breaks { from to } license
            }
        }
        """
        variables = {
            "channel": channel_code.strip(),
            "chunkStart": 0,
            "chunkEnd": 0
        }

        data = self.fetch_gql(query, variables)
        epg_res = data.get("epgHlsUrlV2")
        if not epg_res or not epg_res.get("url"):
            raise Exception(f"Ni bilo mogoče pridobiti toka za kanal {channel_code}.")

        stream_url = epg_res.get("url")
        license_url = epg_res.get("license") or DEFAULT_WV_LICENSE
        encoded_stream_url = urllib.parse.quote(stream_url, safe="")
        license_headers = f"Content-Type=application/octet-stream&X-DRM-Message={encoded_stream_url}"

        return {
            "url": stream_url,
            "manifest_type": "hls",
            "is_drm": bool(epg_res.get("license")),
            "license_type": "com.widevine.alpha",
            "license_url": license_url,
            "license_headers": license_headers
        }

    def fetch_page_html(self, path):
        """Fetches an HTML page from voyo.si."""
        url = path if path.startswith("http") else f"{BASE_URL}{path}"
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "sl,en;q=0.9",
        }
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.read().decode("utf-8", errors="ignore")

    def parse_catalog_items(self, html):
        """
        Extracts catalog items from voyo page using JSON-LD ItemList
        and falls back to HTML card matching.
        """
        items = []
        seen_urls = set()

        # 1. Parse JSON-LD ItemList
        ld_blocks = re.findall(r'<script type=application/ld\+json>(.*?)</script>', html, re.DOTALL)
        for block in ld_blocks:
            try:
                data = json.loads(block)
                if data.get("@type") == "ItemList":
                    for el in data.get("itemListElement", []):
                        raw_item = el.get("item", {})
                        if not raw_item:
                            continue

                        item_type = raw_item.get("@type", "")
                        name = unescape(raw_item.get("name") or raw_item.get("headline") or "")
                        url = raw_item.get("url", "")
                        desc = unescape(raw_item.get("description", "") or "")
                        img = raw_item.get("image") or raw_item.get("thumbnailUrl") or ""
                        duration_iso = raw_item.get("duration", "")
                        duration = parse_iso_duration(duration_iso)

                        if not url or not name:
                            continue

                        # Normalize relative paths to /vsebina/<slug>
                        url = normalize_content_url(url)
                        if url in seen_urls:
                            continue
                        seen_urls.add(url)

                        # Extract media_id if it's a direct video (e.g. /vsebina/name_63643446.html)
                        media_id_match = re.search(r'_(\d+)\.html', url)
                        media_id = media_id_match.group(1) if media_id_match else None

                        is_series = (item_type == "TVSeries" or item_type == "ItemList" or not media_id)

                        items.append({
                            "title": name,
                            "url": url,
                            "media_id": media_id,
                            "is_series": is_series,
                            "description": desc,
                            "image": img,
                            "duration": duration
                        })
            except Exception as e:
                self.logger(f"JSON-LD parse error: {e}")

        # 2. If no items from JSON-LD, parse HTML cards
        if not items:
            cards = re.findall(
                r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>.*?'
                r'<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*alt=[\'"]([^\'"]*)[\'"].*?'
                r'</a>',
                html, re.DOTALL
            )
            for href, img, alt in cards:
                if "/vsebina/" not in href and not href.startswith("/"):
                    continue
                href = normalize_content_url(href)
                if href in seen_urls:
                    continue
                seen_urls.add(href)

                media_id_match = re.search(r'_(\d+)\.html', href)
                media_id = media_id_match.group(1) if media_id_match else None

                items.append({
                    "title": unescape(alt or "Vsebina"),
                    "url": href,
                    "media_id": media_id,
                    "is_series": not bool(media_id),
                    "description": "",
                    "image": img,
                    "duration": 0
                })

        return items

    def get_catalog(self, category_path):
        """Fetches catalog page and returns parsed items."""
        html = self.fetch_page_html(category_path)
        return self.parse_catalog_items(html)

    def get_series_details(self, series_url):
        """
        Fetches series/show page and extracts category ID, seasons, and first season episodes.
        """
        series_url = normalize_content_url(series_url)
        html = self.fetch_page_html(series_url)

        # Title and description
        title_m = re.search(r'<meta property=og:title content="([^"]+)"', html)
        title = unescape(title_m.group(1).replace(" | VOYO", "")) if title_m else "Serija"

        desc_m = re.search(r'<meta property=og:description content="([^"]+)"', html)
        desc = unescape(desc_m.group(1)) if desc_m else ""

        img_m = re.search(r'<meta property=og:image content="([^"]+)"', html)
        img = img_m.group(1) if img_m else ""

        # Category ID
        cat_m = re.search(r'data-category-id=[\'"]?(\d+)', html)
        category_id = cat_m.group(1) if cat_m else None

        # Seasons list
        seasons = []
        se_m = re.search(r'data-season-episodes=[\'"](\[.*?\])[\'"]', html)
        if se_m:
            try:
                se_data = json.loads(se_m.group(1))
                for s in se_data:
                    s_name = s.get("Season")
                    if s_name:
                        seasons.append({
                            "name": s_name,
                            "media_ids": s.get("MediaIds", [])
                        })
            except Exception as e:
                self.logger(f"Error parsing data-season-episodes: {e}")

        # Fallback to season buttons in HTML
        if not seasons:
            s_buttons = re.findall(r'data-season=[\'"]([^\'"]+)[\'"]', html)
            for s_name in s_buttons:
                if not any(s["name"] == s_name for s in seasons):
                    seasons.append({"name": s_name, "media_ids": []})

        if not seasons:
            seasons.append({"name": "Sezona 1", "media_ids": []})

        return {
            "title": title,
            "description": desc,
            "image": img,
            "category_id": category_id,
            "seasons": seasons
        }

    def get_season_episodes(self, category_id, season_name):
        """
        Fetches episodes of a specific season using the /info/voyocategory endpoint.
        Returns list of episode dicts.
        """
        if not category_id:
            return []

        safe_season = urllib.parse.quote(season_name)
        path = f"/info/voyocategory/{category_id}/seasons/{safe_season}/episodes/episodes"
        try:
            html = self.fetch_page_html(path)
        except Exception as e:
            self.logger(f"Error fetching season episodes: {e}")
            return []

        episodes = []
        cards = re.findall(r'<a[^>]+class=[\'"]?[^\'"]*episode[^\'"]*[\'"]?[^>]*>.*?</a>', html, re.DOTALL)
        for card in cards:
            media_id_m = re.search(r'data-uniq=[\'"]?(\d+)', card)
            if not media_id_m:
                media_id_m = re.search(r'onPlayClick\(["\'](\d+)["\']', card)
            if not media_id_m:
                continue
            media_id = media_id_m.group(1)

            short_code_m = re.search(r'data-season-episode-short=[\'"]?([^\'"\s>]+)', card)
            short_code = short_code_m.group(1) if short_code_m else ""

            duration_m = re.search(r'<div[^>]+class=[\'"][^\'"]*\blabel\b[^\'"]*[\'"][^>]*>([^<]+)</div>', card)
            if not duration_m:
                duration_m = re.search(r'<div class=label[^>]*>([^<]+)</div>', card)
            duration_str = duration_m.group(1).strip() if duration_m else ""
            duration = parse_time_duration(duration_str)

            title_m = re.search(r'<h3 class=[\'"]title[^\'"]*[\'"][^>]*>([^<]+)</h3>', card)
            ep_title = unescape(title_m.group(1).strip()) if title_m else f"Epizoda {media_id}"
            if short_code:
                full_title = f"{short_code} - {ep_title}"
            else:
                full_title = ep_title

            summary_m = re.search(r'<div class=[\'"]summary[^\'"]*[\'"][^>]*>([^<]+)</div>', card)
            summary = unescape(summary_m.group(1).strip()) if summary_m else ""

            img_m = re.search(r'<img[^>]+src=[\'"]([^\'"]+)[\'"]', card)
            thumb = img_m.group(1) if img_m else ""

            episodes.append({
                "media_id": media_id,
                "title": full_title,
                "short_code": short_code,
                "description": summary,
                "image": thumb,
                "duration": duration
            })

        return episodes

    def search(self, query):
        """Searches Voyo catalog for given query."""
        safe_q = urllib.parse.quote(query)
        html = self.fetch_page_html(f"/iskanje?q={safe_q}")
        return self.parse_catalog_items(html)
