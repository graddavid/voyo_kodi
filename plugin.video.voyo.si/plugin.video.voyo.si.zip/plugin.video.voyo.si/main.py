# -*- coding: utf-8 -*-
"""
VOYO.si Kodi Video Add-on
Main router and UI controller.
"""

import sys
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from resources.lib.voyo_api import VoyoApi, LIVE_CHANNELS

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ICON = ADDON.getAddonInfo("icon")
ADDON_FANART = ADDON.getAddonInfo("fanart")
ADDON_DATA_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1] else -1


def log(msg, level=xbmc.LOGINFO):
    debug_enabled = ADDON.getSetting("debug") == "true"
    if level == xbmc.LOGDEBUG and not debug_enabled:
        return
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


# Initialize API client
API = VoyoApi(data_dir=ADDON_DATA_DIR, logger=log)


def get_string(string_id):
    """Returns localized string from strings.po."""
    return ADDON.getLocalizedString(string_id)


def build_url(query):
    """Builds plugin internal URL with query parameters."""
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)


def parse_params():
    """Parses query parameters from sys.argv[2]."""
    if len(sys.argv) > 2 and sys.argv[2]:
        param_str = sys.argv[2].lstrip("?")
        return dict(urllib.parse.parse_qsl(param_str))
    return {}


def set_item_info(list_item, info_dict):
    """Sets video info metadata on ListItem safely across Kodi 19-22."""
    try:
        list_item.setInfo("video", info_dict)
    except Exception as e:
        log(f"setInfo error: {e}", xbmc.LOGWARNING)


def ensure_login(force_relogin=False):
    """Checks login state, attempts login using saved credentials if needed."""
    if API.is_logged_in() and not force_relogin:
        return True

    email = ADDON.getSetting("email")
    password = ADDON.getSetting("password")

    if not email or not password:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            get_string(30202),  # Not logged in
            xbmcgui.NOTIFICATION_WARNING,
            4000
        )
        ADDON.openSettings()
        email = ADDON.getSetting("email")
        password = ADDON.getSetting("password")
        if not email or not password:
            return False

    try:
        user_info = API.login(email, password)
        nickname = user_info.get("nickname") or user_info.get("email")
        sub_until = user_info.get("subscriptionUntil", "")
        status_str = f"Prijavljen: {nickname}"
        if sub_until:
            status_str += f" (do {sub_until[:10]})"
        ADDON.setSetting("account_status", status_str)
        return True
    except Exception as e:
        log(f"Login error: {e}", xbmc.LOGERROR)
        ADDON.setSetting("account_status", "Napaka pri prijavi")
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            f"{get_string(30201)}: {e}",
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        return False


# ---------------------------------------------------------------------------
# Navigation Menus
# ---------------------------------------------------------------------------

def show_main_menu():
    """Main menu of the add-on."""
    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "videos")

    menu_items = [
        (get_string(30100), {"action": "bookmarks"}, "DefaultRecentlyAddedVideos.png", True),
        (get_string(30101), {"action": "movies"}, "DefaultMovies.png", True),
        (get_string(30102), {"action": "series"}, "DefaultTVShows.png", True),
        (get_string(30103), {"action": "shows"}, "DefaultFolder.png", True),
        (get_string(30104), {"action": "live_tv"}, "DefaultAddonPVRClient.png", True),
        (get_string(30105), {"action": "catalog", "cat": "/novo", "title": get_string(30105)}, "DefaultYear.png", True),
        (get_string(30106), {"action": "catalog", "cat": "/sport", "title": get_string(30106)}, "DefaultFolder.png", True),
        (get_string(30107), {"action": "search"}, "DefaultAddonsSearch.png", True),
        (get_string(30108), {"action": "open_settings"}, "DefaultAddonService.png", False),
    ]

    for label, query, icon, is_folder in menu_items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            "icon": icon,
            "thumb": icon,
            "fanart": ADDON_FANART
        })
        url = build_url(query)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)


def show_movies_menu():
    """Movies subcategories menu."""
    xbmcplugin.setPluginCategory(HANDLE, get_string(30101))
    xbmcplugin.setContent(HANDLE, "genres")

    genres = [
        ("Vsi filmi", "/filmi/vsi-filmi"),
        ("Slovenski", "/filmi/slovenski"),
        ("Kratki filmi", "/filmi/kratki-filmi"),
        ("Akcija", "/filmi/akcija"),
        ("Komedija", "/filmi/komedija"),
        ("Drama", "/filmi/drama"),
        ("Grozljivka", "/filmi/grozljivka"),
        ("Romanca", "/filmi/romanca"),
        ("Kriminalka", "/filmi/kriminalka"),
        ("Družinski", "/filmi/druzinski"),
        ("Dokumentarni", "/filmi/dokumentarni"),
        ("Biografski", "/filmi/biografski"),
        ("Pustolovski", "/filmi/pustolovski"),
        ("Vojni", "/filmi/vojni"),
        ("ZF & Fantazijski", "/filmi/zf-fantazijski"),
    ]

    for label, cat_path in genres:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultMovies.png", "thumb": "DefaultMovies.png", "fanart": ADDON_FANART})
        url = build_url({"action": "catalog", "cat": cat_path, "title": label})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_series_menu():
    """Series subcategories menu."""
    xbmcplugin.setPluginCategory(HANDLE, get_string(30102))
    xbmcplugin.setContent(HANDLE, "genres")

    genres = [
        ("Vse serije", "/serije"),
        ("VOYO Originali", "/serije/voyo-originali_1"),
        ("Slovenske serije", "/serije/slovenske_1"),
        ("Kriminalne serije", "/serije/kriminalne"),
        ("Komedije", "/serije/komedije"),
        ("Drame", "/serije/drame"),
        ("Balkanske serije", "/serije/balkanske"),
        ("Ameriške serije", "/serije/ameriske_1"),
        ("Evropske serije", "/serije/evropske"),
        ("Turške serije", "/serije/turske"),
        ("Mladinske serije", "/serije/mladinske"),
        ("Dokumentarne serije", "/serije/dokumentarne"),
    ]

    for label, cat_path in genres:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultTVShows.png", "thumb": "DefaultTVShows.png", "fanart": ADDON_FANART})
        url = build_url({"action": "catalog", "cat": cat_path, "title": label})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_shows_menu():
    """Shows subcategories menu."""
    xbmcplugin.setPluginCategory(HANDLE, get_string(30103))
    xbmcplugin.setContent(HANDLE, "genres")

    genres = [
        ("Vse oddaje", "/oddaje"),
        ("VOYO Originali", "/oddaje/voyo-originali"),
        ("Resničnostni šovi", "/oddaje/resnicnostni-sovi"),
        ("Slovenske oddaje", "/oddaje/slovenske"),
        ("Kuharske oddaje", "/oddaje/kuharske"),
        ("Stand-up komedija", "/oddaje/stand-up"),
        ("Zabavne oddaje", "/oddaje/zabavne"),
        ("Informativne oddaje", "/oddaje/informativne-oddaje"),
        ("Otroške oddaje", "/oddaje/otroske"),
    ]

    for label, cat_path in genres:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png", "fanart": ADDON_FANART})
        url = build_url({"action": "catalog", "cat": cat_path, "title": label})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_live_tv():
    """Live TV channels list."""
    xbmcplugin.setPluginCategory(HANDLE, get_string(30104))
    xbmcplugin.setContent(HANDLE, "videos")

    for ch in LIVE_CHANNELS:
        li = xbmcgui.ListItem(label=ch["name"])
        li.setArt({
            "icon": ch["icon"],
            "thumb": ch["icon"],
            "fanart": ADDON_FANART
        })
        set_item_info(li, {
            "title": ch["name"],
            "plot": ch["description"],
            "mediatype": "video"
        })
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_live", "channel": ch["id"]})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def show_catalog(cat_path, title):
    """Displays items from a Voyo catalog path (movies, series, shows)."""
    xbmcplugin.setPluginCategory(HANDLE, title or ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        items = API.get_catalog(cat_path)
    except Exception as e:
        log(f"Error loading catalog {cat_path}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        li = xbmcgui.ListItem(label=item["title"])
        img = item.get("image") or ADDON_ICON
        li.setArt({
            "icon": img,
            "thumb": img,
            "poster": img,
            "fanart": ADDON_FANART
        })

        if item.get("is_series"):
            set_item_info(li, {
                "title": item["title"],
                "plot": item.get("description", ""),
                "mediatype": "tvshow"
            })
            url = build_url({
                "action": "series_seasons",
                "url": item["url"],
                "title": item["title"],
                "image": img
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        else:
            set_item_info(li, {
                "title": item["title"],
                "plot": item.get("description", ""),
                "duration": item.get("duration", 0),
                "mediatype": "movie"
            })
            li.setProperty("IsPlayable", "true")
            url = build_url({
                "action": "play",
                "media_id": item.get("media_id") or ""
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def show_series_seasons(series_url, series_title, series_image):
    """Displays seasons for a given series."""
    xbmcplugin.setPluginCategory(HANDLE, series_title)
    xbmcplugin.setContent(HANDLE, "seasons")

    try:
        details = API.get_series_details(series_url)
    except Exception as e:
        log(f"Error loading series details {series_url}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    category_id = details.get("category_id")
    seasons = details.get("seasons", [])
    img = details.get("image") or series_image or ADDON_ICON

    for season in seasons:
        season_name = season.get("name", "Sezona")
        li = xbmcgui.ListItem(label=season_name)
        li.setArt({
            "icon": img,
            "thumb": img,
            "poster": img,
            "fanart": ADDON_FANART
        })
        set_item_info(li, {
            "title": season_name,
            "tvshowtitle": series_title,
            "plot": details.get("description", ""),
            "mediatype": "season"
        })
        url = build_url({
            "action": "season_episodes",
            "category_id": category_id or "",
            "season": season_name,
            "series_title": series_title,
            "image": img
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_season_episodes(category_id, season_name, series_title, series_image):
    """Displays episodes for a specific season."""
    xbmcplugin.setPluginCategory(HANDLE, f"{series_title} - {season_name}")
    xbmcplugin.setContent(HANDLE, "episodes")

    try:
        episodes = API.get_season_episodes(category_id, season_name)
    except Exception as e:
        log(f"Error loading season episodes: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for ep in episodes:
        li = xbmcgui.ListItem(label=ep["title"])
        thumb = ep.get("image") or series_image or ADDON_ICON
        li.setArt({
            "icon": thumb,
            "thumb": thumb,
            "fanart": ADDON_FANART
        })
        set_item_info(li, {
            "title": ep["title"],
            "tvshowtitle": series_title,
            "plot": ep.get("description", ""),
            "duration": ep.get("duration", 0),
            "mediatype": "episode"
        })
        li.setProperty("IsPlayable", "true")
        url = build_url({
            "action": "play",
            "media_id": ep["media_id"]
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def show_bookmarks():
    """Displays Continue Watching items from user's account."""
    if not ensure_login():
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, get_string(30100))
    xbmcplugin.setContent(HANDLE, "videos")

    bookmarks = API.get_bookmarks()
    if not bookmarks:
        li = xbmcgui.ListItem(label="Ni nedavnih ogledov")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for bm in bookmarks:
        media_id = bm["media_id"]
        label = f"Vsebina #{media_id} ({bm.get('percent', 0)}%)"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultRecentlyAddedVideos.png", "fanart": ADDON_FANART})
        set_item_info(li, {
            "title": label,
            "mediatype": "video",
            "duration": int(bm.get("duration", 0))
        })
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play", "media_id": str(media_id)})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def do_search():
    """Prompts user for search keyword and displays results."""
    dialog = xbmcgui.Dialog()
    query = dialog.input(get_string(30206), type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        return

    xbmcplugin.setPluginCategory(HANDLE, f"{get_string(30107)}: {query}")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        items = API.search(query)
    except Exception as e:
        log(f"Search error: {e}", xbmc.LOGERROR)
        dialog.notification(ADDON_NAME, str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not items:
        dialog.notification(ADDON_NAME, get_string(30207), xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        li = xbmcgui.ListItem(label=item["title"])
        img = item.get("image") or ADDON_ICON
        li.setArt({"icon": img, "thumb": img, "poster": img, "fanart": ADDON_FANART})

        if item.get("is_series"):
            set_item_info(li, {
                "title": item["title"],
                "plot": item.get("description", ""),
                "mediatype": "tvshow"
            })
            url = build_url({
                "action": "series_seasons",
                "url": item["url"],
                "title": item["title"],
                "image": img
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        else:
            set_item_info(li, {
                "title": item["title"],
                "plot": item.get("description", ""),
                "duration": item.get("duration", 0),
                "mediatype": "movie"
            })
            li.setProperty("IsPlayable", "true")
            url = build_url({"action": "play", "media_id": item.get("media_id") or ""})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------------------
# Stream Playback Handlers
# ---------------------------------------------------------------------------

def check_drm_helper(manifest_type="mpd"):
    """Optionally checks InputStream Helper to verify Widevine is installed."""
    try:
        from inputstreamhelper import Helper
        helper = Helper(manifest_type, drm="widevine")
        if not helper.check_inputstream():
            log("InputStream Helper check failed.", xbmc.LOGERROR)
            return False
    except ImportError:
        pass
    return True


def play_video(media_id):
    """Resolves and plays a VOYO on-demand video stream with Widevine DRM."""
    if not ensure_login():
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if not check_drm_helper("mpd"):
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    try:
        stream_info = API.get_video_stream(media_id)
    except Exception as e:
        # Check if error is related to expired token, try relogin once
        err_str = str(e).lower()
        if any(w in err_str for w in ["token", "auth", "dostop", "401", "403", "422"]):
            log("Authentication expired, retrying login...", xbmc.LOGINFO)
            if ensure_login(force_relogin=True):
                try:
                    stream_info = API.get_video_stream(media_id)
                except Exception as e2:
                    log(f"Stream resolution error after relogin: {e2}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification(ADDON_NAME, str(e2), xbmcgui.NOTIFICATION_ERROR, 5000)
                    xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
                    return
            else:
                xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
                return
        else:
            log(f"Stream resolution error for {media_id}: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return

    stream_url = stream_info["url"]
    manifest_type = stream_info.get("manifest_type", "mpd")
    license_url = stream_info.get("license_url")
    license_headers = stream_info.get("license_headers", "")

    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("inputstream", "inputstream.adaptive")
    play_item.setProperty("inputstreamaddon", "inputstream.adaptive")
    play_item.setProperty("inputstream.adaptive.manifest_type", manifest_type)

    if stream_info.get("is_drm"):
        play_item.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
        # Format: <url>|<headers>|b|
        license_key = f"{license_url}|{license_headers}|b|"
        play_item.setProperty("inputstream.adaptive.license_key", license_key)

    # Max resolution / stream quality setting
    try:
        quality_setting = int(ADDON.getSetting("stream_quality") or 0)
        if quality_setting == 1:
            play_item.setProperty("inputstream.adaptive.max_bandwidth", "10000000")
        elif quality_setting == 2:
            play_item.setProperty("inputstream.adaptive.max_bandwidth", "5000000")
        elif quality_setting == 3:
            play_item.setProperty("inputstream.adaptive.max_bandwidth", "2500000")
    except Exception:
        pass

    play_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)


def play_live(channel_code):
    """Resolves and plays a live TV stream."""
    if not ensure_login():
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    if not check_drm_helper("hls"):
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
        return

    try:
        stream_info = API.get_live_stream(channel_code)
    except Exception as e:
        err_str = str(e).lower()
        if any(w in err_str for w in ["token", "auth", "dostop", "401", "403", "422"]):
            log("Live stream auth expired, retrying login...", xbmc.LOGINFO)
            if ensure_login(force_relogin=True):
                try:
                    stream_info = API.get_live_stream(channel_code)
                except Exception as e2:
                    log(f"Live stream error after relogin: {e2}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification(ADDON_NAME, str(e2), xbmcgui.NOTIFICATION_ERROR, 5000)
                    xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
                    return
            else:
                xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
                return
        else:
            log(f"Live stream error for {channel_code}: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return

    stream_url = stream_info["url"]
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("inputstream", "inputstream.adaptive")
    play_item.setProperty("inputstreamaddon", "inputstream.adaptive")
    play_item.setProperty("inputstream.adaptive.manifest_type", "hls")

    if stream_info.get("is_drm"):
        play_item.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
        license_url = stream_info.get("license_url")
        license_headers = stream_info.get("license_headers", "")
        license_key = f"{license_url}|{license_headers}|b|"
        play_item.setProperty("inputstream.adaptive.license_key", license_key)

    play_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)


# ---------------------------------------------------------------------------
# Account & Settings Actions
# ---------------------------------------------------------------------------

def action_test_login():
    """Action callback to test login credentials."""
    email = ADDON.getSetting("email")
    password = ADDON.getSetting("password")

    if not email or not password:
        xbmcgui.Dialog().notification(ADDON_NAME, get_string(30202), xbmcgui.NOTIFICATION_WARNING)
        return

    try:
        user_info = API.login(email, password)
        nickname = user_info.get("nickname") or user_info.get("email")
        sub_until = user_info.get("subscriptionUntil", "")
        status_str = f"Prijavljen: {nickname}"
        if sub_until:
            status_str += f" (do {sub_until[:10]})"
        ADDON.setSetting("account_status", status_str)
        xbmcgui.Dialog().notification(ADDON_NAME, get_string(30200), xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        ADDON.setSetting("account_status", "Napaka pri prijavi")
        xbmcgui.Dialog().notification(ADDON_NAME, f"{get_string(30201)}: {e}", xbmcgui.NOTIFICATION_ERROR)


def action_logout():
    """Action callback to logout and clear session."""
    API.clear_session()
    ADDON.setSetting("account_status", "Odjavljen")
    xbmcgui.Dialog().notification(ADDON_NAME, "Uspešno odjavljen.", xbmcgui.NOTIFICATION_INFO)


def action_clear_cache():
    """Action callback to clear cached session and files."""
    API.clear_session()
    xbmcgui.Dialog().notification(ADDON_NAME, "Predpomnilnik počiščen.", xbmcgui.NOTIFICATION_INFO)


# ---------------------------------------------------------------------------
# Main Routing Entry Point
# ---------------------------------------------------------------------------

def router():
    params = parse_params()
    action = params.get("action", "")

    log(f"Routing action: '{action}' with params {params}", xbmc.LOGDEBUG)

    if not action or action == "root":
        show_main_menu()
    elif action == "movies":
        show_movies_menu()
    elif action == "series":
        show_series_menu()
    elif action == "shows":
        show_shows_menu()
    elif action == "live_tv":
        show_live_tv()
    elif action == "catalog":
        show_catalog(params.get("cat", ""), params.get("title", ""))
    elif action == "series_seasons":
        show_series_seasons(
            params.get("url", ""),
            params.get("title", ""),
            params.get("image", "")
        )
    elif action == "season_episodes":
        show_season_episodes(
            params.get("category_id", ""),
            params.get("season", ""),
            params.get("series_title", ""),
            params.get("image", "")
        )
    elif action == "bookmarks":
        show_bookmarks()
    elif action == "search":
        do_search()
    elif action == "play":
        play_video(params.get("media_id", ""))
    elif action == "play_live":
        play_live(params.get("channel", ""))
    elif action == "test_login":
        action_test_login()
    elif action == "logout":
        action_logout()
    elif action == "clear_cache":
        action_clear_cache()
    elif action == "open_settings":
        ADDON.openSettings()
    elif action == "settings":
        ADDON.openSettings()
    else:
        log(f"Unknown action: {action}", xbmc.LOGWARNING)
        show_main_menu()


if __name__ == "__main__":
    router()
