# -*- coding: utf-8 -*-
"""
VOYO.si API client (no Kodi dependencies, so it can be unit tested).

Session model (mirrors the official voyo.si web client):
  * A random Device-Id is generated ONCE and kept in device.json forever.
    It is sent with every request so VOYO recognises this Kodi as the same
    device. Logging out or clearing the cache never deletes it.
  * The JWT is kept in session.json and refreshed with `loginInfo` instead
    of logging in again with the password.
  * `linkDeviceToUser` is only called when the account reports no deviceId
    for this Device-Id, exactly like the web client. Calling it on every
    login is what used to register a new device on every Kodi start.
"""

import json
import os
import re
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from html import unescape

GQL_URL = "https://gql.voyo.si/v2"
BASE_URL = "https://voyo.si"
TV_PAIR_URL = "voyo.si/nastavitve/naprave/tv"
DEVICES_URL = "voyo.si/nastavitve/naprave"
DEFAULT_WV_LICENSE = "https://wv-ksm.api.24ur.si"
SITE_ID = 30005
DEVICE_FAMILY = "PC"
SESSION_REFRESH_SECONDS = 6 * 3600
SESSION_FORMAT = 3

# Home page rows that aren't regular content (short vertical clips, live TV guide)
HOME_ROWS_SKIP = ("vertical_videos", "voyobox_epg")

GROUP_CONTINUE = "stayedAt"
GROUP_MY_VOYO = "GRP_DEFAULT"

# GraphQL error codes (extensions.message.code)
ERR_BAD_CREDENTIALS = "404.100"
ERR_DEVICE_NOT_PAIRED = "404.200"
ERR_TOO_MANY_DEVICES = "404.300"
ERR_INVALID_TOKEN = "404.400"
AUTH_ERROR_PREFIXES = ("404.400", "422.")

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/128.0.0.0 Safari/537.36"
)

USER_FIELDS = "id token email avatar nickname deviceId profileId status subscriptionUntil profileType isSubscribed"

# Live TV channel mapping for Pro Plus
LIVE_CHANNELS = [
    {"id": "POPTV", "name": "POP TV", "description": "Najbolj gledan slovenski televizijski program.",
     "icon": "https://assets.24ur.si/voyo/channels/poptv.png"},
    {"id": "KANALA", "name": "Kanal A", "description": "Akcija, filmi, šport in zabava.",
     "icon": "https://assets.24ur.si/voyo/channels/kanala.png"},
    {"id": "POPKINO", "name": "KINO", "description": "Najboljši filmi 24 ur na dan.",
     "icon": "https://assets.24ur.si/voyo/channels/kino.png"},
    {"id": "POPBRIO", "name": "BRIO", "description": "Komične nanizanke, priljubljene serije in zabavne oddaje.",
     "icon": "https://assets.24ur.si/voyo/channels/brio.png"},
    {"id": "POPOTO", "name": "OTO", "description": "Prvi slovenski otroški program s sinhroniziranimi risankami.",
     "icon": "https://assets.24ur.si/voyo/channels/oto.png"},
    {"id": "VOYO", "name": "VOYO TV", "description": "Izbor vrhunskih VOYO vsebin in športnih prenosov.",
     "icon": "https://assets.24ur.si/voyo/channels/voyo.png"},
]


class VoyoError(Exception):
    """API error carrying VOYO's error code (e.g. '404.300') when available."""

    def __init__(self, message, code=""):
        super().__init__(message)
        self.code = code or ""

    @property
    def is_auth_error(self):
        return self.code.startswith(AUTH_ERROR_PREFIXES)


class TooManyDevicesError(VoyoError):
    pass


class NotLoggedInError(VoyoError):
    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_iso_duration(duration_str):
    """Converts ISO 8601 duration (e.g. PT1H33M55S) to total seconds."""
    if not duration_str or not duration_str.startswith("PT"):
        return 0
    match = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", duration_str)
    if not match:
        return 0
    hours, minutes, seconds = (int(g or 0) for g in match.groups())
    return hours * 3600 + minutes * 60 + seconds


def parse_time_duration(time_str):
    """Converts MM:SS or HH:MM:SS to total seconds."""
    if not time_str:
        return 0
    parts = time_str.strip().split(":")
    try:
        if len(parts) == 2:
            return int(parts[0]) * 60 + int(parts[1])
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    except (ValueError, TypeError):
        pass
    return 0


SPECIAL_PREFIXES = ("/vsebina/", "/filmi", "/serije", "/oddaje", "/novo", "/sport", "/iskanje", "/info")


def normalize_content_url(url):
    """Makes content URLs site-relative and points bare slugs to /vsebina/<slug>."""
    if not url:
        return ""
    if url.startswith(BASE_URL):
        url = url[len(BASE_URL):] or "/"
    if url.startswith("/") and not url.startswith(SPECIAL_PREFIXES):
        return "/vsebina" + url
    return url


def extract_media_id(url):
    match = re.search(r"_(\d+)\.html", url or "")
    return match.group(1) if match else None


def resize_image(url, size):
    """Rewrites an images.24ur.com URL to a CDN-resized variant, e.g. '800xX'."""
    if not url or "images.24ur.com/media/images/" not in url:
        return url or ""
    url = re.sub(r"(/media/images/)[^/]+/", r"\g<1>%s/" % size, url, count=1)
    # Slides use .jpg.webp variants; plain JPEG decodes on every Kodi version
    return re.sub(r"\.(jpe?g|png)\.webp(?=\?|$)", r".\1", url)


def _attr(pattern, text):
    match = re.search(pattern, text, re.DOTALL)
    return unescape(match.group(1).strip()) if match else ""


def _is_portrait(url):
    size = re.search(r"/media/images/(\d+)x(\d+)/", url)
    return bool(size) and int(size.group(2)) > int(size.group(1))


def _html_section(html, element_id):
    """Returns the markup from the element with the given id up to the next sibling section."""
    start = re.search(r"id=[\"']?%s[\"'\s>]" % re.escape(element_id), html)
    if not start:
        return ""
    rest = html[start.end():]
    end = re.search(r"id=[\"']?(?:stayedat|myvoyo|bookmarks-data)[\"'\s>]", rest)
    return rest[:end.start()] if end else rest


def parse_slides(html):
    """
    Parses voyo.si carousel slides (<li class=splide__slide ...>) into items.
    Used for the home page rows, series posters and account bookmark rows.
    """
    items = []
    seen = set()
    for chunk in re.split(r"<li class=[\"']?splide__slide", html)[1:]:
        chunk = chunk.split("</ul>", 1)[0]
        href = _attr(r"<a[^>]+href=[\"']?([^\"'\s>]+)", chunk)
        if not href or href.startswith("#") or "javascript:" in href:
            continue
        url = normalize_content_url(href)
        if url in seen:
            continue
        seen.add(url)
        uniq = _attr(r"^[^>]*data-uniq=[\"']?([^\"'\s>]+)", chunk)
        title = _attr(r"alt=\"([^\"]*)\"", chunk) or _attr(r"alt=([^\s>]+)", chunk)
        if not title:
            title = _attr(r"<span>([^<]+)</span>", chunk)
        poster = landscape = ""
        for src in re.findall(r"(?:srcset|src)=\"([^\"\s]+)", chunk):
            if _is_portrait(src):
                poster = poster or src
            else:
                landscape = landscape or src
        subtitle = _attr(r"text-white/60[^>]*>([^<]+)<", chunk)
        progress = _attr(r"width:\s*(\d+(?:\.\d+)?)%", chunk)
        media_id = extract_media_id(url)
        items.append({
            "title": title or url.rsplit("/", 1)[-1],
            "url": url,
            "media_id": media_id,
            "uniq": uniq,
            "is_series": not media_id,
            "is_live": "/v-zivo/" in url,
            "description": subtitle,
            "image": landscape,
            "poster": poster,
            "duration": 0,
            "percent": float(progress) if progress else 0,
        })
    return items


# ---------------------------------------------------------------------------
# API client
# ---------------------------------------------------------------------------

class VoyoApi:
    def __init__(self, data_dir=None, logger=None, device_name="Kodi", device_model="Kodi"):
        self.data_dir = data_dir or os.path.expanduser("~")
        self.device_file = os.path.join(self.data_dir, "device.json")
        self.session_file = os.path.join(self.data_dir, "session.json")
        self.legacy_file = os.path.join(self.data_dir, "voyo_session.json")
        self.logger = logger or (lambda msg: None)
        self.device_name = device_name or "Kodi"
        self.device_model = device_model or "Kodi"
        self.device_id = ""
        self.token = ""
        self.user_data = {}
        self.checked_at = 0
        self._load()

    # -- persistence --------------------------------------------------------

    def _read_json(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def _write_json(self, path, data):
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError as e:
            self.logger(f"Error writing {path}: {e}")

    def _load(self):
        device = self._read_json(self.device_file)
        session = self._read_json(self.session_file)

        # Migrate from v1.0.x which kept everything in voyo_session.json
        if os.path.exists(self.legacy_file):
            legacy = self._read_json(self.legacy_file)
            device = device or {"device_id": legacy.get("device_id", "")}
            session = session or {"token": legacy.get("token", ""), "user": legacy.get("user_data", {}),
                                  "format": SESSION_FORMAT}
            try:
                os.remove(self.legacy_file)
            except OSError:
                pass
            self._write_json(self.session_file, session)

        self.device_id = device.get("device_id", "")
        if not self.device_id:
            self.device_id = str(uuid.uuid4())
            self._write_json(self.device_file, {"device_id": self.device_id, "created": int(time.time())})
        elif not os.path.exists(self.device_file):
            self._write_json(self.device_file, {"device_id": self.device_id, "created": int(time.time())})

        # Sessions saved by 1.1.0 may hold a profile token that can't play video;
        # drop them so the add-on logs in again (same device id, no new device).
        if session.get("format") != SESSION_FORMAT:
            session = {}

        self.token = session.get("token", "")
        self.user_data = session.get("user", {}) or {}
        self.checked_at = session.get("checked_at", 0)

    def _save_session(self):
        self._write_json(self.session_file, {
            "token": self.token,
            "user": self.user_data,
            "checked_at": self.checked_at,
            "format": SESSION_FORMAT,
        })

    def clear_session(self):
        """Forgets the login locally. The device id is intentionally kept."""
        self.token = ""
        self.user_data = {}
        self.checked_at = 0
        try:
            os.remove(self.session_file)
        except OSError:
            pass

    def reset_device_id(self):
        """Generates a new device id. VOYO will treat this Kodi as a new device."""
        self.clear_session()
        self.device_id = str(uuid.uuid4())
        self._write_json(self.device_file, {"device_id": self.device_id, "created": int(time.time())})

    def is_logged_in(self):
        return bool(self.token)

    def _set_user(self, user):
        if not user or not user.get("token"):
            raise VoyoError("Strežnik ni vrnil podatkov o prijavi.")
        self.token = user["token"]
        self.user_data = user
        self.checked_at = int(time.time())
        self._save_session()
        return user

    # -- transport ----------------------------------------------------------

    def _headers(self, extra=None):
        headers = {
            "User-Agent": USER_AGENT,
            "Onl-Location": BASE_URL + "/",
            "Origin": BASE_URL,
            "Referer": BASE_URL + "/",
            "Device-Id": self.device_id,
        }
        if self.token:
            headers["Authorization"] = self.token
        headers.update(extra or {})
        return headers

    def fetch_gql(self, query, variables=None, timeout=15):
        """Executes a GraphQL query and returns the `data` dict. Raises VoyoError."""
        payload = json.dumps({"query": query, "variables": variables or {}}).encode("utf-8")
        req = urllib.request.Request(
            GQL_URL, data=payload, method="POST",
            headers=self._headers({"Content-Type": "application/json"}),
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                res = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="ignore")
            self.logger(f"GQL HTTP Error {e.code}: {body[:500]}")
            code = "422.0" if e.code in (401, 403) else str(e.code)
            raise VoyoError(f"HTTP napaka {e.code}: {e.reason}", code)
        except urllib.error.URLError as e:
            raise VoyoError(f"Napaka povezave: {e.reason}")
        except ValueError:
            raise VoyoError("Neveljaven odgovor strežnika.")

        errors = res.get("errors") or []
        if errors:
            err = errors[0]
            ext = (err.get("extensions") or {}).get("message") or {}
            code = ext.get("code", "") if isinstance(ext, dict) else ""
            msg = (ext.get("tMessage") if isinstance(ext, dict) else "") or err.get("message", "Napaka GQL")
            self.logger(f"GQL error {code}: {err.get('message')}")
            if code == ERR_TOO_MANY_DEVICES:
                raise TooManyDevicesError(msg, code)
            raise VoyoError(msg, code)
        return res.get("data") or {}

    def fetch_page_html(self, path, authenticated=False):
        """Fetches an HTML page from voyo.si."""
        url = path if path.startswith("http") else f"{BASE_URL}{path}"
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "sl,en;q=0.9",
        }
        if authenticated and self.token:
            headers.update({
                "Authorization": self.token,
                "Device-Id": str(self.user_data.get("deviceId") or self.device_id),
                "Onl-Location": BASE_URL + "/",
            })
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                if authenticated and resp.geturl().rstrip("/") == BASE_URL:
                    raise VoyoError("Seja je potekla.", ERR_INVALID_TOKEN)
                return resp.read().decode("utf-8", errors="ignore")
        except urllib.error.HTTPError as e:
            raise VoyoError(f"HTTP napaka {e.code}: {e.reason}", str(e.code))
        except urllib.error.URLError as e:
            raise VoyoError(f"Napaka povezave: {e.reason}")

    # -- authentication -----------------------------------------------------

    def login(self, email, password):
        """Logs in with e-mail and password, then makes sure the device is linked."""
        query = f"""
        query loginUser($email: String!, $siteId: Int!, $password: String!) {{
            login(email: $email, siteId: $siteId, password: $password) {{ {USER_FIELDS} }}
        }}"""
        data = self.fetch_gql(query, {"email": email.strip(), "password": password, "siteId": SITE_ID})
        self._set_user(data.get("login"))
        self._finish_login()
        return self.user_data

    def request_tv_code(self):
        """Requests a pairing code the user enters at voyo.si/nastavitve/naprave/tv."""
        query = """
        mutation tvGetCode($deviceName: String!, $deviceFamily: String!) {
            tvGetCode(deviceName: $deviceName, deviceFamily: $deviceFamily, codeLength: 5) { code }
        }"""
        data = self.fetch_gql(query, {"deviceName": self.device_name, "deviceFamily": DEVICE_FAMILY})
        code = (data.get("tvGetCode") or {}).get("code")
        if not code:
            raise VoyoError("Kode za prijavo ni bilo mogoče pridobiti.")
        return code

    def poll_tv_login(self):
        """Returns the user once the pairing code was confirmed, otherwise None."""
        query = f"""
        query LoginDevice($deviceName: String!, $deviceFamily: String!, $siteId: Int) {{
            loginDevice(deviceName: $deviceName, deviceFamily: $deviceFamily, siteId: $siteId) {{ {USER_FIELDS} }}
        }}"""
        try:
            data = self.fetch_gql(query, {"deviceName": self.device_name, "deviceFamily": DEVICE_FAMILY,
                                          "siteId": SITE_ID})
        except VoyoError as e:
            if e.code == ERR_DEVICE_NOT_PAIRED:
                return None
            raise
        user = data.get("loginDevice")
        if not user or not user.get("token"):
            return None
        self._set_user(user)
        self._finish_login()
        return self.user_data

    def _finish_login(self):
        """
        Tries to link this device to the account, but never fails the login.
        VOYO often rejects the link for Kodi (e.g. "visitor not set deviceId");
        v1.0.x ignored that too and playback works without it.
        """
        try:
            self.ensure_device_linked()
        except VoyoError as e:
            self.logger(f"Device linking skipped: {e} ({e.code})")

    def ensure_device_linked(self):
        """Links this device only if VOYO doesn't know it yet (same as the web client)."""
        if self.user_data.get("deviceId"):
            return self.user_data
        query = f"""
        query LinkDeviceToUser($deviceFamily: String!, $deviceName: String!, $deviceModel: String!) {{
            linkDeviceToUser(deviceFamily: $deviceFamily, deviceName: $deviceName, deviceModel: $deviceModel) {{
                {USER_FIELDS}
            }}
        }}"""
        data = self.fetch_gql(query, {"deviceFamily": DEVICE_FAMILY, "deviceName": self.device_name,
                                      "deviceModel": self.device_model})
        user = data.get("linkDeviceToUser")
        if user and user.get("token"):
            self._set_user(user)
        return self.user_data

    def refresh_session(self, force=False):
        """
        Refreshes the JWT with `loginInfo` (no password, no new device).
        Raises VoyoError with is_auth_error=True when the session is no longer valid.
        Network errors are swallowed so an offline check doesn't log the user out.
        """
        if not self.token:
            raise NotLoggedInError("Niste prijavljeni.", ERR_INVALID_TOKEN)
        if not force and time.time() - self.checked_at < SESSION_REFRESH_SECONDS:
            return self.user_data
        query = f"""
        query loginInfo($token: String!, $siteId: Int!) {{
            loginInfo(token: $token, siteId: $siteId) {{ {USER_FIELDS} }}
        }}"""
        try:
            data = self.fetch_gql(query, {"token": self.token, "siteId": SITE_ID})
        except VoyoError as e:
            if e.is_auth_error:
                self.clear_session()
                raise
            self.logger(f"Session refresh skipped: {e}")
            return self.user_data
        user = data.get("loginInfo")
        if not user:
            self.clear_session()
            raise NotLoggedInError("Seja je potekla.", ERR_INVALID_TOKEN)
        self._set_user(user)
        return self.user_data

    def logout(self, remove_device=False):
        """Logs out on the server (optionally removing this device from the account)."""
        if self.token:
            if remove_device and self.user_data.get("deviceId"):
                try:
                    self.fetch_gql("query unlinkDevice($id: Int!) { unlinkDevice(id: $id) { token } }",
                                   {"id": int(self.user_data["deviceId"])})
                except (VoyoError, ValueError) as e:
                    self.logger(f"unlinkDevice failed: {e}")
            try:
                self.fetch_gql("query logoutJwt { logoutJwt { status } }")
            except VoyoError as e:
                self.logger(f"logoutJwt failed: {e}")
        self.clear_session()

    # -- bookmarks ----------------------------------------------------------

    def get_bookmark_groups(self):
        """Returns {group_id: [ {media_id, key, percent, duration}, ... ]}."""
        query = """
        query voyoBookmarks {
            voyoBookmark { groups { id name items { entityId categoryId data { percent duration } } } }
        }"""
        data = self.fetch_gql(query)
        groups = {}
        for group in (data.get("voyoBookmark") or {}).get("groups") or []:
            items = []
            for item in group.get("items") or []:
                info = item.get("data") or {}
                items.append({
                    "media_id": str(item.get("entityId") or ""),
                    "key": str(item.get("categoryId") or item.get("entityId") or ""),
                    "percent": info.get("percent") or 0,
                    "duration": info.get("duration") or 0,
                })
            groups[group.get("id")] = items
        return groups

    def get_bookmarks(self, group_id):
        """
        Bookmarked items with titles and artwork, taken from the same
        server-rendered rows voyo.si shows on its home page.
        Falls back to the bare GraphQL list if the page can't be parsed.
        """
        groups = self.get_bookmark_groups()
        raw = groups.get(group_id, [])
        if not raw:
            return []
        by_id = {b["media_id"]: b for b in raw}
        by_key = {b["key"]: b for b in raw}
        try:
            html = self.fetch_page_html(f"/bookmark/voyobox_slides?t={int(time.time())}", authenticated=True)
            items = parse_slides(_html_section(html, "stayedat" if group_id == GROUP_CONTINUE else "myvoyo"))
            for item in items:
                bm = by_id.get(item["media_id"] or "") or by_key.get(item["uniq"]) or {}
                if bm:
                    item["percent"] = bm.get("percent") or item["percent"]
                    item["duration"] = bm.get("duration") or 0
                    item["bookmark_key"] = bm["media_id"] if item["media_id"] else bm["key"]
                else:
                    item["bookmark_key"] = item["media_id"] or item["uniq"]
            if items:
                return items
        except VoyoError as e:
            self.logger(f"Bookmark slides unavailable: {e}")
        return [{
            "title": f"Vsebina #{b['media_id']}",
            "url": "",
            "media_id": b["media_id"],
            "uniq": b["key"],
            "bookmark_key": b["media_id"],
            "is_series": False,
            "is_live": False,
            "description": "",
            "image": "",
            "poster": "",
            "duration": b["duration"],
            "percent": b["percent"],
        } for b in raw if b["media_id"]]

    def add_bookmark(self, item_id, group_id=GROUP_MY_VOYO):
        query = """
        mutation voyoBookmarkAdd($groupId: String!, $itemId: String!, $percent: Int, $duration: Int) {
            voyoBookmarkAdd(groupId: $groupId, itemId: $itemId, returnAllBookmarks: false,
                            percent: $percent, duration: $duration) { __typename }
        }"""
        self.fetch_gql(query, {"groupId": group_id, "itemId": str(item_id), "percent": 0, "duration": 0})

    def remove_bookmark(self, item_id, group_id=GROUP_MY_VOYO):
        query = """
        mutation voyoBookmarkDelete($groupId: String!, $itemId: String!) {
            voyoBookmarkDelete(groupId: $groupId, itemId: $itemId) { __typename }
        }"""
        self.fetch_gql(query, {"groupId": group_id, "itemId": str(item_id)})

    # -- streams ------------------------------------------------------------

    @staticmethod
    def _license_headers(stream_url):
        # Widevine license header: X-DRM-Message contains the exact stream URL
        return "Content-Type=application/octet-stream&X-DRM-Message=" + urllib.parse.quote(stream_url, safe="")

    def get_video_stream(self, media_id):
        """Resolves the DASH manifest and Widevine license for an on-demand video."""
        if not media_id or not str(media_id).strip().isdigit():
            raise VoyoError("ID videa ni veljaven.")
        query = """
        query VideoUrlV2($id: Int!, $siteId: Int) {
            videoUrlV2(id: $id, siteId: $siteId) { url info infoCode license }
        }"""
        data = self.fetch_gql(query, {"id": int(str(media_id).strip()), "siteId": SITE_ID})
        video = data.get("videoUrlV2")
        if not video:
            raise VoyoError("Strežnik ni vrnil podatkov o videu.")

        info_code = video.get("infoCode", 0)
        info_msg = video.get("info", "")
        if info_code in (503, 507):
            raise VoyoError(info_msg or "Vsebine ni mogoče predvajati. Naročnina ni aktivna.", str(info_code))
        if info_code:
            self.logger(f"Video stream infoCode {info_code}: {info_msg}")

        stream_url = video.get("url")
        if not stream_url or "NOVIDEO" in stream_url:
            raise VoyoError(info_msg or "Video tok ni na voljo.")

        is_dash = ".mpd" in stream_url or "dash" in stream_url.lower()
        return {
            "url": stream_url,
            "is_drm": True,
            "manifest_type": "mpd" if is_dash else "hls",
            "license_url": video.get("license") or DEFAULT_WV_LICENSE,
            "license_headers": self._license_headers(stream_url),
            "info": info_msg,
        }

    def get_live_stream(self, channel_code):
        """Resolves the live HLS stream of a Pro Plus channel (known not to work yet)."""
        query = """
        query EpgHlsUrlV2($channel: String!, $chunkStart: Int!, $chunkEnd: Int!) {
            epgHlsUrlV2(channel: $channel, chunkStart: $chunkStart, chunkEnd: $chunkEnd) {
                url breaks { from to } license
            }
        }"""
        data = self.fetch_gql(query, {"channel": channel_code.strip(), "chunkStart": 0, "chunkEnd": 0})
        epg = data.get("epgHlsUrlV2")
        if not epg or not epg.get("url"):
            raise VoyoError(f"Ni bilo mogoče pridobiti toka za kanal {channel_code}.")
        stream_url = epg["url"]
        return {
            "url": stream_url,
            "manifest_type": "hls",
            "is_drm": bool(epg.get("license")),
            "license_url": epg.get("license") or DEFAULT_WV_LICENSE,
            "license_headers": self._license_headers(stream_url),
        }

    # -- catalog scraping ---------------------------------------------------

    def parse_catalog_items(self, html):
        """
        Extracts catalog items from the JSON-LD ItemList, enriched with posters
        and bookmark keys from the page's slide markup. Falls back to slides only.
        """
        slides = {s["url"]: s for s in parse_slides(html)}
        # Grid cards (e.g. search results): <a href=URL><div class=card>...<img src=IMG>
        card_images = {}
        for href, img in re.findall(
                r"<a href=[\"']?([^\"'\s>]+)[\"']?><div class=[\"']?card[\"'\s>](?:(?!</a>).)*?<img[^>]+src=\"([^\"]+)\"",
                html, re.DOTALL):
            card_images.setdefault(normalize_content_url(href), img)
        items = []
        seen = set()

        for block in re.findall(r"<script type=[\"']?application/ld\+json[\"']?>(.*?)</script>", html, re.DOTALL):
            try:
                data = json.loads(block)
            except ValueError as e:
                self.logger(f"JSON-LD parse error: {e}")
                continue
            if not isinstance(data, dict) or data.get("@type") != "ItemList":
                continue
            for el in data.get("itemListElement", []):
                raw = el.get("item") or {}
                name = unescape(raw.get("name") or raw.get("headline") or "")
                url = normalize_content_url(raw.get("url", ""))
                if not url or not name or url in seen:
                    continue
                seen.add(url)
                media_id = extract_media_id(url)
                slide = dict(slides.get(url, {}))
                card = card_images.get(url, "")
                if card:
                    slide.setdefault("poster" if _is_portrait(card) else "image", card)
                items.append({
                    "title": name,
                    "url": url,
                    "media_id": media_id,
                    "uniq": slide.get("uniq", ""),
                    "is_series": raw.get("@type") in ("TVSeries", "ItemList") or not media_id,
                    "is_live": "/v-zivo/" in url,
                    "description": unescape(raw.get("description") or ""),
                    "image": raw.get("image") or raw.get("thumbnailUrl") or slide.get("image", ""),
                    "poster": slide.get("poster", ""),
                    "duration": parse_iso_duration(raw.get("duration", "")),
                    "percent": 0,
                })

        if not items:
            items = list(slides.values())
        return items

    def get_catalog(self, category_path):
        return self.parse_catalog_items(self.fetch_page_html(category_path))

    def get_home_rows(self):
        """Returns the curated rows from the voyo.si home page."""
        html = self.fetch_page_html("/")
        rows = []
        for chunk in re.split(r"<div data-box-id=", html)[1:]:
            box_id = _attr(r"^[\"']?([\w-]+)", chunk)
            title = _attr(r"<h2 class=[\"']?slider__title[^>]*>(.*?)</h2>", chunk)
            title = re.sub(r"<[^>]+>", "", title).strip()
            if box_id in HOME_ROWS_SKIP:
                continue
            items = [i for i in parse_slides(chunk) if not i["is_live"]]
            if box_id and title and items:
                rows.append({"id": box_id, "title": title, "items": items})
        return rows

    def get_series_details(self, series_url):
        """Fetches a series/show page: title, description, category id and seasons."""
        html = self.fetch_page_html(normalize_content_url(series_url))

        title = _attr(r"<meta property=[\"']?og:title[\"']? content=\"([^\"]+)\"", html)
        title = re.sub(r"\s*[-|]\s*(Glej .*|VOYO)$", "", title)
        desc = _attr(r"<meta property=[\"']?og:description[\"']? content=\"([^\"]+)\"", html)
        img = _attr(r"<meta property=[\"']?og:image[\"']? content=\"([^\"]+)\"", html)
        category_id = _attr(r"data-category-id=[\"']?(\d+)", html) or None

        seasons = []
        se_m = re.search(r"data-season-episodes=[\"'](\[.*?\])[\"']", html)
        if se_m:
            try:
                for s in json.loads(unescape(se_m.group(1))):
                    if s.get("Season"):
                        seasons.append({"name": s["Season"], "media_ids": s.get("MediaIds", [])})
            except ValueError as e:
                self.logger(f"Error parsing data-season-episodes: {e}")

        if not seasons:
            for s_name in re.findall(r"data-season=[\"']([^\"']+)[\"']", html):
                if not any(s["name"] == s_name for s in seasons):
                    seasons.append({"name": unescape(s_name), "media_ids": []})

        if not seasons and category_id:
            seasons.append({"name": "Sezona 1", "media_ids": []})

        return {
            "title": title or "Serija",
            "description": desc,
            "image": img,
            "category_id": category_id,
            "seasons": seasons,
        }

    def get_season_episodes(self, category_id, season_name):
        """Fetches the episodes of one season via the /info/voyocategory endpoint."""
        if not category_id:
            return []
        path = f"/info/voyocategory/{category_id}/seasons/{urllib.parse.quote(season_name)}/episodes/episodes"
        html = self.fetch_page_html(path)

        episodes = []
        cards = re.findall(r"<a[^>]+class=[\"']?[^\"'>]*episode[^\"'>]*[\"']?[^>]*>.*?</a>", html, re.DOTALL)
        for card in cards:
            media_id = _attr(r"data-uniq=[\"']?(\d+)", card) or _attr(r"onPlayClick\([\"'](\d+)[\"']", card)
            if not media_id:
                continue
            short_code = _attr(r"data-season-episode-short=[\"']?([^\"'\s>]+)", card)
            duration_str = (_attr(r"<div[^>]+class=[\"'][^\"']*\blabel\b[^\"']*[\"'][^>]*>([^<]+)</div>", card)
                            or _attr(r"<div class=label[^>]*>([^<]+)</div>", card))
            ep_title = _attr(r"<h3 class=[\"']?title[^>]*>([^<]+)</h3>", card) or f"Epizoda {media_id}"
            summary = _attr(r"<div class=[\"']?summary[^>]*>([^<]+)</div>", card)
            thumb = _attr(r"<img[^>]+src=[\"']([^\"']+)[\"']", card)

            season_no = episode_no = 0
            code_m = re.match(r"S(\d+)\D*E(\d+)", short_code, re.I)
            if code_m:
                season_no, episode_no = int(code_m.group(1)), int(code_m.group(2))

            episodes.append({
                "media_id": media_id,
                "title": f"{short_code} - {ep_title}" if short_code else ep_title,
                "episode_title": ep_title,
                "short_code": short_code,
                "season": season_no,
                "episode": episode_no,
                "description": summary,
                "image": thumb,
                "duration": parse_time_duration(duration_str),
            })
        return episodes

    def search(self, query):
        return self.parse_catalog_items(self.fetch_page_html(f"/iskanje?q={urllib.parse.quote(query)}"))
