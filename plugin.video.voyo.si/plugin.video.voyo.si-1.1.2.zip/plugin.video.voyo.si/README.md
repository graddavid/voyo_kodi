# VOYO.si Kodi Video Add-on (`plugin.video.voyo.si`)

Neuradni vtičnik za **Kodi** (19 Matrix, 20 Nexus, 21 Omega, 22 Piers) za ogled vsebin s platforme **VOYO.si** z obstoječim naročniškim računom.

---

## 🚀 Funkcije

- **Prijava**
  - **S kodo (priporočeno za TV):** Kodi prikaže 5-mestno kodo, ki jo na telefonu ali računalniku vnesete na `voyo.si/nastavitve/naprave/tv`. Gesla ni treba tipkati z daljincem.
  - **Z e-pošto in geslom** prek dialoga v dodatku.
  - Seja se samodejno osvežuje. Kodi se **ne registrira kot nova naprava** ob vsakem zagonu.
- **Ena naprava na Kodi:** trajni ID naprave ostane enak ob ponovnem zagonu, odjavi in posodobitvah. Ob odjavi lahko Kodi tudi odstranite z računa in sprostite mesto (VOYO dovoli do 5 naprav).
- **Nadaljuj z ogledom** z naslovi, slikami in nadaljevanjem na mestu, kjer ste ostali.
- **Moj VOYO:** dodajanje/odstranjevanje iz kontekstnega menija.
- **Izpostavljeno:** vrstice z naslovnice voyo.si (Top 10, Kmalu, Novo, …).
- **Filmi, serije, oddaje, šport, novo** po žanrih, s sezonami in epizodami.
- **Iskanje** z zgodovino iskanj.
- **Predvajanje z Widevine DRM** prek `inputstream.adaptive` (samodejno nameščen kot odvisnost).
- **TV v živo:** še ne deluje.

---

## 📦 Namestitev

1. V Kodiju vključite **Nastavitve → Sistem → Dodatki → Neznani viri**.
2. **Dodatki → Namesti iz datoteke zip** → izberite `repository.voyo.si.zip`.
3. **Dodatki → Namesti iz repozitorija → VOYO.si Repository → Video dodatki → VOYO.si**.
   `InputStream Adaptive` in `InputStream Helper` se namestita samodejno.

## 🔑 Prijava

Odprite dodatek in izberite **Prijava v VOYO** (ali **Nastavitve → Račun → Prijava**) in nato:

- **Prijava s kodo:** na telefonu odprite `voyo.si/nastavitve/naprave/tv` in vpišite kodo s TV zaslona.
- **Prijava z e-pošto in geslom:** vpišite podatke. Če je vključeno *Zapomni si geslo*, se dodatek ob poteku seje samodejno prijavi znova, na isti napravi.

Če je na računu že 5 naprav, dodatek to jasno sporoči. Na `voyo.si/nastavitve/naprave` odstranite napravo, ki je ne uporabljate več.

## ⚙️ Nastavitve

| Razdelek | Možnosti |
|---|---|
| **Račun** | stanje računa, prijava / odjava, e-pošta, geslo, samodejna ponovna prijava |
| **Naprava** | ime naprave na voyo.si, ID naprave, ponastavitev naprave |
| **Predvajanje** | največja ločljivost, nastavitve InputStream Adaptive, namestitev Widevine |
| **Napredno** | podrobno beleženje, brisanje zgodovine iskanja |

## 💡 Widevine

- **Android / Google TV:** Widevine je vgrajen.
- **Windows / Linux / LibreELEC:** ob prvem predvajanju (ali v *Nastavitve → Predvajanje → Namesti Widevine*) InputStream Helper prenese Widevine CDM.
